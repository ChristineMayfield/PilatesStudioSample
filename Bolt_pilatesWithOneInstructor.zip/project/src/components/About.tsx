import React from 'react';
import { Award, Heart, Target, Users } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Award,
      title: "Basi Certified",
      description: "Trained in the authentic Basi method, ensuring precise and effective movement patterns."
    },
    {
      icon: Heart,
      title: "Holistic Approach",
      description: "Focus on mind-body connection, breathing techniques, and overall wellness."
    },
    {
      icon: Target,
      title: "Personalized Training",
      description: "Every session is tailored to your unique needs, goals, and physical condition."
    },
    {
      icon: Users,
      title: "Individual Attention",
      description: "Private sessions ensure you receive dedicated focus and proper form correction."
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              About Your Instructor
            </h2>
            <div className="w-24 h-1 bg-sage-600 mx-auto mb-8"></div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <div className="space-y-6">
              <h3 className="font-serif text-3xl font-bold text-gray-800 mb-4">
                Sarah Johnson
              </h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                With over 8 years of experience in Pilates instruction and a deep passion for movement, 
                I specialize in the Basi method - a comprehensive approach that emphasizes precision, 
                control, and the integration of mind, body, and spirit.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                My journey began with my own transformation through Pilates, recovering from a back injury 
                that led me to discover the profound healing power of this practice. Since then, I've dedicated 
                my career to helping others achieve their wellness goals through personalized, attentive instruction.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Every session in my studio is designed to meet you exactly where you are, whether you're 
                a beginner seeking foundation or an advanced practitioner looking to deepen your practice.
              </p>
            </div>
            
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/4056535/pexels-photo-4056535.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&fit=crop"
                alt="Sarah Johnson, Pilates Instructor"
                className="w-full h-96 object-cover rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-sage-600 text-white p-4 rounded-lg shadow-lg">
                <p className="font-bold text-lg">8+ Years</p>
                <p className="text-sm">Experience</p>
              </div>
            </div>
          </div>

          <div className="mb-20">
            <h3 className="font-serif text-3xl font-bold text-gray-800 text-center mb-12">
              The Basi Method
            </h3>
            <div className="bg-sage-50 rounded-xl p-8 md:p-12">
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The Basi method is a contemporary approach to Pilates that maintains the integrity of Joseph Pilates' 
                original work while incorporating modern knowledge of movement science and anatomy. This method emphasizes:
              </p>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-xl text-sage-800 mb-3">Core Principles</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Centering and core stability</li>
                    <li>• Concentration and mindful movement</li>
                    <li>• Control and precision</li>
                    <li>• Breathing and flow</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-xl text-sage-800 mb-3">Benefits</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Improved posture and alignment</li>
                    <li>• Enhanced flexibility and strength</li>
                    <li>• Better body awareness</li>
                    <li>• Stress reduction and mental clarity</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="bg-sage-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-sage-200 transition-colors duration-300">
                  <feature.icon className="w-8 h-8 text-sage-600" />
                </div>
                <h4 className="font-semibold text-xl text-gray-800 mb-3">{feature.title}</h4>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;