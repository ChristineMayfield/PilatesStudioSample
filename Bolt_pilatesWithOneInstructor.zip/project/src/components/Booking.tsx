import React, { useState } from 'react';
import { Calendar, Clock, CheckCircle, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useConfig } from '../hooks/useConfig';
import { useSupabaseSessions } from '../hooks/useSupabaseSessions';
import { useSupabaseClients, Client } from '../hooks/useSupabaseClients';
import ClientTypeahead from './ClientTypeahead';
import NewClientModal from './NewClientModal';

const Booking = () => {
  const { config } = useConfig();
  const { getAvailableSlots, bookSession, dateToLocalString, loading: sessionsLoading } = useSupabaseSessions();
  const { clients, createClient, loading: clientsLoading } = useSupabaseClients();
  
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showNewClientModal, setShowNewClientModal] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [sessionNotes, setSessionNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isBooking, setIsBooking] = useState(false);

  // Helper function to format time with AM/PM
  const formatTimeWithAMPM = (time: string): string => {
    // If time already has AM/PM, return as is
    if (time.includes('AM') || time.includes('PM')) {
      return time;
    }
    
    // Parse time and add AM/PM
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const isDateAvailable = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (date < today) return false;
    
    const slots = getAvailableSlots(date);
    return slots.length > 0;
  };

  const nextMonth = () => {
    const next = new Date(currentMonth);
    next.setMonth(next.getMonth() + 1);
    
    // Only allow next month, not beyond
    const today = new Date();
    const maxMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
    
    if (next <= maxMonth) {
      setCurrentMonth(next);
      setSelectedDate(null);
      setSelectedTime('');
    }
  };

  const prevMonth = () => {
    const prev = new Date(currentMonth);
    prev.setMonth(prev.getMonth() - 1);
    
    // Don't allow going to previous months
    const today = new Date();
    if (prev.getMonth() >= today.getMonth() && prev.getFullYear() >= today.getFullYear()) {
      setCurrentMonth(prev);
      setSelectedDate(null);
      setSelectedTime('');
    }
  };

  const handleTimeSelection = (date: Date, time: string) => {
    setSelectedDate(date);
    setSelectedTime(time);
    setShowModal(true);
  };

  const handleClientSelect = (client: Client | null) => {
    setSelectedClient(client);
  };

  const handleCreateNewClient = () => {
    setShowNewClientModal(true);
  };

  const handleNewClientSave = async (clientData: any) => {
    const newClient = await createClient(clientData);
    if (newClient) {
      setSelectedClient(newClient);
      setShowNewClientModal(false);
      return true;
    }
    return false;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDate || !selectedTime || !selectedClient) {
      alert('Please select a client and ensure all required fields are filled.');
      return;
    }

    setIsBooking(true);

    const bookingData = {
      date: dateToLocalString(selectedDate),
      time: selectedTime,
      client_id: selectedClient.id,
      session_type: 'consultation',
      notes: sessionNotes
    };

    const success = await bookSession(bookingData);
    setIsBooking(false);

    if (success) {
      setIsSubmitted(true);
      setShowModal(false);
    } else {
      alert('Failed to book session. Please try again.');
    }
  };

  const resetForm = () => {
    setSelectedDate(null);
    setSelectedTime('');
    setSelectedClient(null);
    setSessionNotes('');
    setIsSubmitted(false);
    setShowModal(false);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedTime('');
    setSelectedClient(null);
    setSessionNotes('');
  };

  if (isSubmitted) {
    return (
      <section id="booking" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-green-50 rounded-2xl p-12">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-6" />
              <h2 className="font-serif text-3xl font-bold text-gray-800 mb-4">
                Consultation Booked!
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Thank you for booking the consultation. I'll confirm the appointment and 
                send preparation details within 24 hours.
              </p>
              <div className="bg-white rounded-lg p-6 mb-6 text-left">
                <h3 className="font-semibold text-lg mb-3">Consultation Details:</h3>
                <p><strong>Date:</strong> {selectedDate?.toLocaleDateString()}</p>
                <p><strong>Time:</strong> {formatTimeWithAMPM(selectedTime)}</p>
                <p><strong>Duration:</strong> 40 minutes</p>
                <p><strong>Type:</strong> Initial Consultation</p>
                <p><strong>Client:</strong> {selectedClient?.name}</p>
                <p><strong>Email:</strong> {selectedClient?.email}</p>
                <p><strong>Phone:</strong> {selectedClient?.phone}</p>
              </div>
              <button
                onClick={() => window.location.href = '/'}
                className="bg-sage-600 hover:bg-sage-700 text-white px-8 py-3 rounded-full font-semibold transition-colors duration-300"
              >
                Return Home
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <section id="booking" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              Book Your Initial Consultation
            </h2>
            <div className="w-24 h-1 bg-sage-600 mx-auto mb-8"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Start your Pilates journey with a personalized 40-minute consultation. We'll assess your 
              needs, discuss your goals, and create a plan tailored specifically for you.
            </p>
            <div className="mt-6 inline-flex items-center bg-sage-100 rounded-lg px-6 py-3">
              <Clock className="w-5 h-5 text-sage-700 mr-2" />
              <span className="text-sage-800 font-medium">40-minute session • {config.consultationFee}</span>
            </div>
          </div>

          {/* Loading State */}
          {(sessionsLoading || clientsLoading) && (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sage-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading available appointments...</p>
            </div>
          )}

          {/* Calendar */}
          {!sessionsLoading && !clientsLoading && (
            <div className="bg-sage-50 rounded-xl p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <Calendar className="w-6 h-6 text-sage-600 mr-3" />
                  <h3 className="text-2xl font-bold text-gray-800">Choose Your Date & Time</h3>
                </div>
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    onClick={prevMonth}
                    disabled={currentMonth.getMonth() === new Date().getMonth()}
                    className="p-2 rounded-full hover:bg-sage-100 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronLeft className="w-5 h-5 text-sage-600" />
                  </button>
                  <h4 className="text-xl font-semibold text-gray-800 min-w-[200px] text-center">
                    {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                  </h4>
                  <button
                    type="button"
                    onClick={nextMonth}
                    disabled={currentMonth.getMonth() > new Date().getMonth()}
                    className="p-2 rounded-full hover:bg-sage-100 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronRight className="w-5 h-5 text-sage-600" />
                  </button>
                </div>
              </div>
              
              {/* Day Headers */}
              <div className="grid grid-cols-7 gap-2 mb-4">
                {dayNames.map(day => (
                  <div key={day} className="text-center text-sm font-medium text-sage-700 py-2">
                    {day}
                  </div>
                ))}
              </div>
              
              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {getDaysInMonth(currentMonth).map((date, index) => (
                  <div key={index} className="min-h-[120px]">
                    {date && (
                      <div className={`h-full rounded-lg border transition-colors duration-200 ${
                        isDateAvailable(date)
                          ? 'bg-white border-sage-200 hover:border-sage-300 shadow-sm'
                          : 'bg-sage-100 border-sage-200 opacity-50'
                      }`}>
                        <div className="p-2">
                          <div className={`text-sm font-medium mb-2 ${
                            isDateAvailable(date) ? 'text-gray-700' : 'text-sage-500'
                          }`}>
                            {date.getDate()}
                          </div>
                          {isDateAvailable(date) && (
                            <div className="space-y-1">
                              {getAvailableSlots(date).map((time) => (
                                <button
                                  key={time}
                                  type="button"
                                  onClick={() => handleTimeSelection(date, time)}
                                  className="w-full text-xs bg-sage-200 hover:bg-sage-300 text-sage-800 px-2 py-1 rounded transition-colors duration-200 font-medium"
                                >
                                  {formatTimeWithAMPM(time)}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Booking Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-serif text-2xl font-bold text-gray-800">Complete Your Booking</h3>
                <button
                  onClick={closeModal}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="bg-sage-50 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-gray-800 mb-2">Selected Appointment:</h4>
                <p className="text-gray-600">
                  <strong>Date:</strong> {selectedDate?.toLocaleDateString()} <br />
                  <strong>Time:</strong> {formatTimeWithAMPM(selectedTime)} <br />
                  <strong>Duration:</strong> 40 minutes <br />
                  <strong>Price:</strong> {config.consultationFee}
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Client Selection */}
                <ClientTypeahead
                  clients={clients}
                  selectedClient={selectedClient}
                  onClientSelect={handleClientSelect}
                  onCreateNewClient={handleCreateNewClient}
                  disabled={isBooking}
                />

                {/* Session Notes */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Session Notes (Optional)
                  </label>
                  <textarea
                    value={sessionNotes}
                    onChange={(e) => setSessionNotes(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 transition-colors duration-200 resize-none"
                    placeholder="Any specific areas to focus on, concerns, or preparation notes..."
                    disabled={isBooking}
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    type="button"
                    onClick={closeModal}
                    disabled={isBooking}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-3 rounded-full font-semibold transition-colors duration-300 disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!selectedClient || isBooking}
                    className="flex-1 bg-sage-600 hover:bg-sage-700 text-white px-6 py-3 rounded-full font-semibold transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isBooking ? 'Booking...' : `Book Consultation (${config.consultationFee})`}
                  </button>
                </div>
              </form>

              <p className="text-sm text-gray-600 mt-4 text-center">
                * I'll confirm your appointment within 24 hours via email or phone
              </p>
            </div>
          </div>
        </div>
      )}

      {/* New Client Modal */}
      <NewClientModal
        isOpen={showNewClientModal}
        onClose={() => setShowNewClientModal(false)}
        onSave={handleNewClientSave}
      />
    </section>
  );
};

export default Booking;