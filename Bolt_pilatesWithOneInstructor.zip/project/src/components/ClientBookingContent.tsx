import React, { useState, useEffect } from 'react';
import { Calendar, Clock, CheckCircle, ArrowLeft, CreditCard, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useSupabaseSessions } from '../hooks/useSupabaseSessions';
import { useSupabaseClients, Client } from '../hooks/useSupabaseClients';
import { useAuth } from '../hooks/useAuth';
import ClientTypeahead from './ClientTypeahead';
import NewClientModal from './NewClientModal';

interface SessionWithClient {
  id: string;
  date: string;
  time: string;
  status: string;
  duration_minutes: number;
  notes?: string;
  client?: {
    id: string;
    name: string;
    email: string;
  };
}

const ClientBookingContent = () => {
  const { user } = useAuth();
  const { getAvailableSlots, bookSession, dateToLocalString, loading: sessionsLoading, sessions } = useSupabaseSessions();
  const { clients, createClient, loading: clientsLoading } = useSupabaseClients();
  
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showNewClientModal, setShowNewClientModal] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [sessionNotes, setSessionNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isBooking, setIsBooking] = useState(false);

  // Get current user's client record
  const currentUserClient = clients.find(client => client.id === user?.id);

  // Helper function to format time with AM/PM
  const formatTimeWithAMPM = (time: string): string => {
    // If time already has AM/PM, return as is
    if (time.includes('AM') || time.includes('PM')) {
      return time;
    }
    
    // Parse time and add AM/PM
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  // Get status color and styling
  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'available':
        return {
          bgColor: 'bg-green-100',
          textColor: 'text-green-800',
          borderColor: 'border-green-200'
        };
      case 'confirmed':
        return {
          bgColor: 'bg-blue-100',
          textColor: 'text-blue-800',
          borderColor: 'border-blue-200'
        };
      case 'pending_confirmation':
        return {
          bgColor: 'bg-yellow-100',
          textColor: 'text-yellow-800',
          borderColor: 'border-yellow-200'
        };
      case 'completed':
        return {
          bgColor: 'bg-gray-100',
          textColor: 'text-gray-800',
          borderColor: 'border-gray-200'
        };
      default:
        return {
          bgColor: 'bg-gray-100',
          textColor: 'text-gray-800',
          borderColor: 'border-gray-200'
        };
    }
  };

  // Status options for client portal (excluding 'blocked')
  const clientStatusOptions = [
    { value: 'available', label: 'Available', color: 'bg-green-500' },
    { value: 'pending_confirmation', label: 'Pending Confirmation', color: 'bg-yellow-500' },
    { value: 'confirmed', label: 'Confirmed', color: 'bg-blue-500' },
    { value: 'completed', label: 'Completed', color: 'bg-gray-500' }
  ];

  // Mock client credits - in a real app, this would come from the selected client
  const getClientCredits = (client: Client | null) => {
    if (!client) return { remaining: 0, total: 0, packageType: 'No Package' };
    return {
      remaining: client.sessions_remaining,
      total: client.sessions_remaining + 2, // Mock calculation
      packageType: client.package_type || 'Pay Per Session'
    };
  };

  const clientCredits = getClientCredits(selectedClient || currentUserClient);

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const isDateAvailable = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (date < today) return false;
    
    const slots = getAvailableSlots(date);
    return slots.length > 0;
  };

  // Get sessions for a specific date - only show user's booked sessions and available sessions
  const getSessionsForDate = (date: Date): SessionWithClient[] => {
    const dateStr = dateToLocalString(date);
    
    return sessions.filter(session => {
      if (session.date !== dateStr) return false;
      
      // Show available sessions
      if (session.status === 'available') return true;
      
      // Show sessions booked by current user (including past sessions)
      if (session.client_id === user?.id) return true;
      
      return false;
    }).map(session => ({
      id: session.id,
      date: session.date,
      time: session.time,
      status: session.status,
      duration_minutes: session.duration_minutes,
      notes: session.notes,
      client: session.client_id === user?.id ? { 
        id: user.id, 
        name: user.name, 
        email: user.email 
      } : undefined
    }));
  };

  const nextMonth = () => {
    const next = new Date(currentMonth);
    next.setMonth(next.getMonth() + 1);
    
    // Allow navigation up to 3 months ahead for existing clients
    const today = new Date();
    const maxMonth = new Date(today.getFullYear(), today.getMonth() + 3, 1);
    
    if (next <= maxMonth) {
      setCurrentMonth(next);
      setSelectedDate(null);
      setSelectedTime('');
    }
  };

  const prevMonth = () => {
    const prev = new Date(currentMonth);
    prev.setMonth(prev.getMonth() - 1);
    
    // Don't allow going to previous months
    const today = new Date();
    if (prev.getMonth() >= today.getMonth() && prev.getFullYear() >= today.getFullYear()) {
      setCurrentMonth(prev);
      setSelectedDate(null);
      setSelectedTime('');
    }
  };

  const handleTimeSelection = (date: Date, time: string, status: string) => {
    // Only allow booking available sessions
    if (status !== 'available') return;
    
    setSelectedDate(date);
    setSelectedTime(time);
    // Auto-select current user's client record if available
    if (currentUserClient) {
      setSelectedClient(currentUserClient);
    }
    setShowModal(true);
  };

  const handleClientSelect = (client: Client | null) => {
    setSelectedClient(client);
  };

  const handleCreateNewClient = () => {
    setShowNewClientModal(true);
  };

  const handleNewClientSave = async (clientData: any) => {
    const newClient = await createClient(clientData);
    if (newClient) {
      setSelectedClient(newClient);
      setShowNewClientModal(false);
      return true;
    }
    return false;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDate || !selectedTime || !selectedClient) {
      alert('Please select a client and ensure all required fields are filled.');
      return;
    }

    if (clientCredits.remaining <= 0) {
      alert('This client has no remaining session credits. Please purchase a new package or use pay-per-session.');
      return;
    }

    setIsBooking(true);

    const bookingData = {
      date: dateToLocalString(selectedDate),
      time: selectedTime,
      client_id: selectedClient.id,
      session_type: 'regular',
      notes: sessionNotes
    };

    const success = await bookSession(bookingData);
    setIsBooking(false);

    if (success) {
      setIsSubmitted(true);
      setShowModal(false);
    } else {
      alert('Failed to book session. Please try again.');
    }
  };

  const resetForm = () => {
    setSelectedDate(null);
    setSelectedTime('');
    setSelectedClient(null);
    setSessionNotes('');
    setIsSubmitted(false);
    setShowModal(false);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedTime('');
    setSelectedClient(null);
    setSessionNotes('');
  };

  if (isSubmitted) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="max-w-2xl mx-auto text-center">
              <div className="bg-green-50 rounded-2xl p-12">
                <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-6" />
                <h2 className="font-serif text-3xl font-bold text-gray-800 mb-4">
                  Session Booked Successfully!
                </h2>
                <p className="text-lg text-gray-600 mb-6">
                  The session has been confirmed. I'll send a reminder 24 hours before the appointment.
                </p>
                <div className="bg-white rounded-lg p-6 mb-6 text-left">
                  <h3 className="font-semibold text-lg mb-3">Session Details:</h3>
                  <p><strong>Date:</strong> {selectedDate?.toLocaleDateString()}</p>
                  <p><strong>Time:</strong> {formatTimeWithAMPM(selectedTime)}</p>
                  <p><strong>Duration:</strong> 60 minutes</p>
                  <p><strong>Client:</strong> {selectedClient?.name}</p>
                  <p><strong>Remaining Credits:</strong> {clientCredits.remaining - 1}</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    onClick={resetForm}
                    className="bg-sage-600 hover:bg-sage-700 text-white px-8 py-3 rounded-full font-semibold transition-colors duration-300"
                  >
                    Book Another Session
                  </button>
                  <Link
                    to="/"
                    className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-8 py-3 rounded-full font-semibold transition-colors duration-300 text-center"
                  >
                    Return Home
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="pt-20">
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center mb-8">
              <Link 
                to="/" 
                className="flex items-center text-sage-600 hover:text-sage-700 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Home
              </Link>
            </div>

            <div className="text-center mb-16">
              <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 mb-6">
                Book Your Next Session
              </h1>
              <div className="w-24 h-1 bg-sage-600 mx-auto mb-8"></div>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Welcome back, {user?.name}! 
                Select an available time slot to book your appointment.
              </p>
              
              {/* Current User Credits Display */}
              {currentUserClient && (
                <div className="mt-8 inline-flex items-center bg-sage-100 rounded-lg px-6 py-3">
                  <CreditCard className="w-5 h-5 text-sage-700 mr-2" />
                  <span className="text-sage-800 font-medium">
                    You have {currentUserClient.sessions_remaining} session credits remaining
                  </span>
                </div>
              )}
            </div>

            {/* Loading State */}
            {(sessionsLoading || clientsLoading) && (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sage-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading available appointments...</p>
              </div>
            )}

            {/* Calendar */}
            {!sessionsLoading && !clientsLoading && (
              <div className="bg-sage-50 rounded-xl p-8">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <Calendar className="w-6 h-6 text-sage-600 mr-3" />
                    <h3 className="text-2xl font-bold text-gray-800">Choose Date & Time</h3>
                  </div>
                  <div className="flex items-center space-x-4">
                    <button
                      type="button"
                      onClick={prevMonth}
                      disabled={currentMonth.getMonth() === new Date().getMonth()}
                      className="p-2 rounded-full hover:bg-sage-100 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ChevronLeft className="w-5 h-5 text-sage-600" />
                    </button>
                    <h4 className="text-xl font-semibold text-gray-800 min-w-[200px] text-center">
                      {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                    </h4>
                    <button
                      type="button"
                      onClick={nextMonth}
                      disabled={currentMonth.getMonth() > new Date().getMonth() + 2}
                      className="p-2 rounded-full hover:bg-sage-100 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ChevronRight className="w-5 h-5 text-sage-600" />
                    </button>
                  </div>
                </div>
                
                {/* Status Legend */}
                <div className="mb-4 flex flex-wrap items-center gap-4 text-sm">
                  <span className="text-gray-600 font-medium">Status:</span>
                  {clientStatusOptions.map(status => (
                    <div key={status.value} className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${status.color}`}></div>
                      <span className="text-gray-700">{status.label}</span>
                    </div>
                  ))}
                </div>
                
                <div className="grid grid-cols-7 gap-2 mb-4">
                  {dayNames.map(day => (
                    <div key={day} className="text-center text-sm font-medium text-sage-700 py-2">
                      {day}
                    </div>
                  ))}
                </div>
                
                <div className="grid grid-cols-7 gap-2">
                  {getDaysInMonth(currentMonth).map((date, index) => {
                    if (!date) {
                      return <div key={index} className="min-h-[140px]"></div>;
                    }

                    const daySessions = getSessionsForDate(date);
                    const isToday = date.toDateString() === new Date().toDateString();

                    return (
                      <div key={index} className="min-h-[140px]">
                        <div className={`h-full rounded-lg border transition-colors duration-200 ${
                          isToday 
                            ? 'border-sage-400 bg-sage-50' 
                            : 'border-gray-200 bg-white hover:border-gray-300'
                        }`}>
                          <div className="p-2">
                            <div className={`text-sm font-medium mb-2 ${
                              isToday ? 'text-sage-700' : 'text-gray-700'
                            }`}>
                              {date.getDate()}
                            </div>
                            
                            {/* Sessions for this day */}
                            <div className="space-y-1">
                              {daySessions.map((session) => {
                                const statusStyle = getStatusStyle(session.status);
                                const isClickable = session.status === 'available';
                                
                                return (
                                  <button
                                    key={session.id}
                                    type="button"
                                    onClick={() => isClickable && handleTimeSelection(date, session.time, session.status)}
                                    disabled={!isClickable}
                                    className={`w-full text-xs px-2 py-1 rounded transition-colors duration-200 font-medium border ${
                                      statusStyle.bgColor
                                    } ${statusStyle.textColor} ${statusStyle.borderColor} ${
                                      isClickable 
                                        ? 'hover:opacity-80 cursor-pointer' 
                                        : 'cursor-default opacity-75'
                                    }`}
                                    title={`${formatTimeWithAMPM(session.time)} - ${session.status}${session.client ? ` (${session.client.name})` : ''}`}
                                  >
                                    <div className="truncate">
                                      {formatTimeWithAMPM(session.time)}
                                    </div>
                                    {session.status !== 'available' && (
                                      <div className="text-xs opacity-75 truncate">
                                        {session.status === 'confirmed' && session.client ? 'Booked' : 
                                         session.status === 'completed' ? 'Done' :
                                         session.status === 'pending_confirmation' ? 'Pending' :
                                         session.status}
                                      </div>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Booking Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-serif text-2xl font-bold text-gray-800">Complete Booking</h3>
                <button
                  onClick={closeModal}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="bg-sage-50 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-gray-800 mb-2">Selected Time Slot:</h4>
                <p className="text-gray-600">
                  <strong>Date:</strong> {selectedDate?.toLocaleDateString()} <br />
                  <strong>Time:</strong> {formatTimeWithAMPM(selectedTime)} <br />
                  <strong>Duration:</strong> 60 minutes
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Client Selection - Show current user by default but allow admin to change */}
                <ClientTypeahead
                  clients={clients}
                  selectedClient={selectedClient}
                  onClientSelect={handleClientSelect}
                  onCreateNewClient={handleCreateNewClient}
                  placeholder="Booking for..."
                  disabled={isBooking}
                />

                {/* Credits Display */}
                {selectedClient && (
                  <div className="bg-sage-50 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <CreditCard className="w-5 h-5 text-sage-600" />
                        <div>
                          <h4 className="font-semibold text-gray-800">{selectedClient.name}'s Credits</h4>
                          <p className="text-sm text-gray-600">{clientCredits.packageType}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-sage-600">{clientCredits.remaining}</p>
                        <p className="text-xs text-gray-600">sessions remaining</p>
                      </div>
                    </div>
                    {clientCredits.remaining <= 2 && clientCredits.remaining > 0 && (
                      <div className="mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded text-yellow-800 text-sm">
                        {selectedClient.name} is running low on credits! Consider discussing a new package.
                      </div>
                    )}
                    {clientCredits.remaining <= 0 && (
                      <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded text-red-800 text-sm">
                        {selectedClient.name} has no remaining credits. Please add a package or use pay-per-session.
                      </div>
                    )}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Session Notes (Optional)
                  </label>
                  <textarea
                    value={sessionNotes}
                    onChange={(e) => setSessionNotes(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 transition-colors duration-200 resize-none"
                    placeholder="Any specific areas to focus on, concerns, or preparation notes..."
                    disabled={isBooking}
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    type="button"
                    onClick={closeModal}
                    disabled={isBooking}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-3 rounded-full font-semibold transition-colors duration-300 disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!selectedClient || clientCredits.remaining <= 0 || isBooking}
                    className={`flex-1 px-6 py-3 rounded-full font-semibold transition-colors duration-300 ${
                      !selectedClient || clientCredits.remaining <= 0 || isBooking
                        ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                        : 'bg-sage-600 hover:bg-sage-700 text-white'
                    }`}
                  >
                    {isBooking ? 'Booking...' : 
                     !selectedClient ? 'Select Client First' :
                     clientCredits.remaining <= 0 ? 'No Credits Remaining' : 
                     'Book Session (1 Credit)'}
                  </button>
                </div>
              </form>

              {selectedClient && (
                <p className="text-sm text-gray-600 mt-4 text-center">
                  * This will use 1 of {selectedClient.name}'s remaining {clientCredits.remaining} session credits
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Client Modal */}
      <NewClientModal
        isOpen={showNewClientModal}
        onClose={() => setShowNewClientModal(false)}
        onSave={handleNewClientSave}
      />
    </div>
  );
};

export default ClientBookingContent;