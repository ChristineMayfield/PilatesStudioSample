import React, { useState, useRef, useEffect } from 'react';
import { Search, Plus, User, ChevronDown } from 'lucide-react';
import { Client } from '../hooks/useSupabaseClients';

interface ClientTypeaheadProps {
  clients: Client[];
  selectedClient: Client | null;
  onClientSelect: (client: Client | null) => void;
  onCreateNewClient: () => void;
  placeholder?: string;
  disabled?: boolean;
}

const ClientTypeahead: React.FC<ClientTypeaheadProps> = ({
  clients,
  selectedClient,
  onClientSelect,
  onCreateNewClient,
  placeholder = "Search for existing client...",
  disabled = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredClients, setFilteredClients] = useState<Client[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Filter clients based on search query
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredClients([]);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = clients.filter(client =>
      client.name.toLowerCase().includes(query) ||
      client.email.toLowerCase().includes(query)
    );
    setFilteredClients(filtered);
  }, [searchQuery, clients]);

  // Handle input focus
  const handleInputFocus = () => {
    setIsOpen(true);
  };

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    
    if (selectedClient && value !== selectedClient.name) {
      onClientSelect(null);
    }
    
    setIsOpen(true);
  };

  // Handle client selection
  const handleClientSelect = (client: Client) => {
    setSearchQuery(client.name);
    onClientSelect(client);
    setIsOpen(false);
  };

  // Handle create new client
  const handleCreateNew = () => {
    onCreateNewClient();
    setIsOpen(false);
  };

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Update search query when selected client changes
  useEffect(() => {
    if (selectedClient) {
      setSearchQuery(selectedClient.name);
    } else {
      setSearchQuery('');
    }
  }, [selectedClient]);

  const showCreateOption = searchQuery.trim().length > 0 && 
    !filteredClients.some(client => client.name.toLowerCase() === searchQuery.toLowerCase());

  return (
    <div className="relative">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Client *
      </label>
      
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={handleInputChange}
            onFocus={handleInputFocus}
            disabled={disabled}
            className="w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 transition-colors duration-200 disabled:bg-gray-100 disabled:cursor-not-allowed"
            placeholder={placeholder}
            autoComplete="off"
          />
          <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        </div>

        {/* Selected Client Info */}
        {selectedClient && (
          <div className="mt-2 p-3 bg-sage-50 border border-sage-200 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <User className="w-4 h-4 text-sage-600" />
              <span className="font-medium text-sage-800">{selectedClient.name}</span>
            </div>
            <div className="text-sm text-sage-600 space-y-1">
              <p><strong>Email:</strong> {selectedClient.email}</p>
              <p><strong>Phone:</strong> {selectedClient.phone}</p>
              {selectedClient.sessions_remaining > 0 && (
                <p><strong>Sessions Remaining:</strong> {selectedClient.sessions_remaining}</p>
              )}
            </div>
          </div>
        )}

        {/* Dropdown */}
        {isOpen && (
          <div
            ref={dropdownRef}
            className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto"
          >
            {/* Filtered clients */}
            {filteredClients.length > 0 && (
              <div className="py-2">
                <div className="px-3 py-1 text-xs font-medium text-gray-500 uppercase tracking-wide">
                  Existing Clients
                </div>
                {filteredClients.map((client) => (
                  <button
                    key={client.id}
                    type="button"
                    onClick={() => handleClientSelect(client)}
                    className="w-full px-3 py-2 text-left hover:bg-sage-50 focus:bg-sage-50 focus:outline-none transition-colors duration-150"
                  >
                    <div className="flex items-center space-x-2">
                      <User className="w-4 h-4 text-sage-600 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 truncate">{client.name}</p>
                        <p className="text-sm text-gray-500 truncate">{client.email}</p>
                        {client.sessions_remaining > 0 && (
                          <p className="text-xs text-sage-600">
                            {client.sessions_remaining} sessions remaining
                          </p>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Create new client option */}
            {showCreateOption && (
              <div className="py-2 border-t border-gray-200">
                <div className="px-3 py-1 text-xs font-medium text-gray-500 uppercase tracking-wide">
                  New Client
                </div>
                <button
                  type="button"
                  onClick={handleCreateNew}
                  className="w-full px-3 py-2 text-left hover:bg-blue-50 focus:bg-blue-50 focus:outline-none transition-colors duration-150"
                >
                  <div className="flex items-center space-x-2">
                    <Plus className="w-4 h-4 text-blue-600 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-blue-900">
                        Create new client: "{searchQuery}"
                      </p>
                      <p className="text-sm text-blue-600">
                        Add this person as a new client
                      </p>
                    </div>
                  </div>
                </button>
              </div>
            )}

            {/* No results */}
            {searchQuery.trim() && filteredClients.length === 0 && !showCreateOption && (
              <div className="py-4 px-3 text-center text-gray-500">
                <p className="text-sm">No clients found matching "{searchQuery}"</p>
              </div>
            )}

            {/* Empty state */}
            {!searchQuery.trim() && (
              <div className="py-4 px-3 text-center text-gray-500">
                <p className="text-sm">Start typing to search for clients</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientTypeahead;