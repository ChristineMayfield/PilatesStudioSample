import React, { useState, useEffect } from 'react';
import { Database, CheckCircle, AlertCircle, Loader, Wifi, WifiOff } from 'lucide-react';
import { supabase } from '../lib/supabase';

const ConnectionTest = () => {
  const [connectionStatus, setConnectionStatus] = useState<'testing' | 'connected' | 'error'>('testing');
  const [configData, setConfigData] = useState<any>(null);
  const [sessionsData, setSessionsData] = useState<any[]>([]);
  const [clientsData, setClientsData] = useState<any[]>([]);
  const [error, setError] = useState<string>('');

  const testConnection = async () => {
    try {
      setConnectionStatus('testing');
      setError('');

      // Test 1: Check site configuration
      console.log('Testing site configuration...');
      const { data: configResult, error: configError } = await supabase
        .from('site_config')
        .select('*')
        .limit(1);

      if (configError) {
        throw new Error(`Config test failed: ${configError.message}`);
      }

      setConfigData(configResult?.[0] || null);

      // Test 2: Check sessions data with client relationships
      console.log('Testing sessions data...');
      const { data: sessionsResult, error: sessionsError } = await supabase
        .from('sessions')
        .select(`
          *,
          client:clients(name, email)
        `)
        .limit(10);

      if (sessionsError) {
        throw new Error(`Sessions test failed: ${sessionsError.message}`);
      }

      setSessionsData(sessionsResult || []);

      // Test 3: Check clients data
      console.log('Testing clients data...');
      const { data: clientsResult, error: clientsError } = await supabase
        .from('clients')
        .select('*')
        .limit(5);

      if (clientsError) {
        throw new Error(`Clients test failed: ${clientsError.message}`);
      }

      setClientsData(clientsResult || []);

      setConnectionStatus('connected');
      console.log('✅ All database tests passed!');
    } catch (err: any) {
      console.error('❌ Database connection failed:', err);
      setError(err.message);
      setConnectionStatus('error');
    }
  };

  useEffect(() => {
    testConnection();
  }, []);

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case 'testing':
        return <Loader className="w-6 h-6 text-blue-600 animate-spin" />;
      case 'connected':
        return <CheckCircle className="w-6 h-6 text-green-600" />;
      case 'error':
        return <AlertCircle className="w-6 h-6 text-red-600" />;
    }
  };

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'testing':
        return 'border-blue-200 bg-blue-50';
      case 'connected':
        return 'border-green-200 bg-green-50';
      case 'error':
        return 'border-red-200 bg-red-50';
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className={`border-2 rounded-xl p-8 ${getStatusColor()}`}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <Database className="w-8 h-8 text-sage-600" />
            <h2 className="text-2xl font-bold text-gray-800">Database Connection Test</h2>
          </div>
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <span className="font-semibold text-lg">
              {connectionStatus === 'testing' && 'Testing...'}
              {connectionStatus === 'connected' && 'Connected'}
              {connectionStatus === 'error' && 'Error'}
            </span>
          </div>
        </div>

        {connectionStatus === 'testing' && (
          <div className="text-center py-8">
            <p className="text-lg text-gray-600">Testing connection to Supabase database...</p>
            <p className="text-sm text-gray-500 mt-2">This may take a few seconds</p>
          </div>
        )}

        {connectionStatus === 'error' && (
          <div className="bg-red-100 border border-red-300 rounded-lg p-6">
            <div className="flex items-center mb-4">
              <WifiOff className="w-6 h-6 text-red-600 mr-3" />
              <h3 className="text-lg font-semibold text-red-800">Connection Failed</h3>
            </div>
            <p className="text-red-700 mb-4">{error}</p>
            <div className="bg-red-50 rounded-lg p-4">
              <h4 className="font-semibold text-red-800 mb-2">Troubleshooting Steps:</h4>
              <ol className="list-decimal list-inside text-red-700 space-y-1 text-sm">
                <li>Check that your Supabase project URL and anon key are correct in .env.local</li>
                <li>Verify your Supabase project is active and not paused</li>
                <li>Ensure the database tables were created successfully</li>
                <li>Check your internet connection</li>
                <li>Make sure the .env.local file is in the root directory</li>
              </ol>
            </div>
            <button
              onClick={testConnection}
              className="mt-4 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors duration-200"
            >
              Retry Connection
            </button>
          </div>
        )}

        {connectionStatus === 'connected' && (
          <div className="space-y-6">
            <div className="flex items-center mb-4">
              <Wifi className="w-6 h-6 text-green-600 mr-3" />
              <h3 className="text-lg font-semibold text-green-800">Successfully Connected!</h3>
            </div>

            {/* Environment Variables Status */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                Environment Configuration
              </h4>
              <div className="text-sm text-gray-600">
                <p><strong>Supabase URL:</strong> {import.meta.env.VITE_SUPABASE_URL ? '✅ Configured' : '❌ Missing'}</p>
                <p><strong>Anon Key:</strong> {import.meta.env.VITE_SUPABASE_ANON_KEY ? '✅ Configured' : '❌ Missing'}</p>
                <p><strong>Connection:</strong> ✅ Active</p>
              </div>
            </div>

            {/* Configuration Data */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                Site Configuration
              </h4>
              {configData ? (
                <div className="text-sm text-gray-600">
                  <p><strong>Consultation Fee:</strong> {configData.config_data?.consultationFee}</p>
                  <p><strong>Pricing Packages:</strong> {configData.config_data?.pricingPackages?.length} packages</p>
                  <p><strong>Add-on Services:</strong> {configData.config_data?.addOnServices?.length} services</p>
                  <p><strong>Last Updated:</strong> {new Date(configData.updated_at).toLocaleString()}</p>
                </div>
              ) : (
                <p className="text-gray-500 text-sm">No configuration data found</p>
              )}
            </div>

            {/* Sessions Data */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                Sessions Data (Normalized Schema)
              </h4>
              <p className="text-sm text-gray-600 mb-3">
                <strong>Total Sessions Found:</strong> {sessionsData.length}
              </p>
              {sessionsData.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">
                    <strong>Available Slots:</strong> {sessionsData.filter(s => s.is_available).length}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Booked Sessions:</strong> {sessionsData.filter(s => !s.is_available).length}
                  </p>
                  <div className="bg-gray-50 rounded p-3 mt-3">
                    <p className="text-xs text-gray-500 mb-2">Sample sessions with client references:</p>
                    {sessionsData.slice(0, 3).map((session, index) => (
                      <div key={index} className="text-xs text-gray-600">
                        {session.date} at {session.time} - {session.is_available ? 'Available' : `Booked by ${session.client?.name || 'Unknown Client'}`}
                        {session.client_id && <span className="text-blue-600 ml-2">(Client ID: {session.client_id.substring(0, 8)}...)</span>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Clients Data */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                Clients Data
              </h4>
              <p className="text-sm text-gray-600 mb-3">
                <strong>Total Clients Found:</strong> {clientsData.length}
              </p>
              {clientsData.length > 0 && (
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-xs text-gray-500 mb-2">Sample clients:</p>
                  {clientsData.slice(0, 3).map((client, index) => (
                    <div key={index} className="text-xs text-gray-600">
                      {client.name} ({client.email}) - {client.sessions_remaining} sessions remaining
                      <span className="text-blue-600 ml-2">(ID: {client.id.substring(0, 8)}...)</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-green-100 border border-green-300 rounded-lg p-4">
              <h4 className="font-semibold text-green-800 mb-2">✅ Environment File Configuration Test Results</h4>
              <ul className="text-green-700 text-sm space-y-1">
                <li>✓ Environment variables loaded from .env.local</li>
                <li>✓ Database connection established</li>
                <li>✓ Site configuration loaded successfully</li>
                <li>✓ Sessions table using UUID foreign keys</li>
                <li>✓ Client data properly normalized</li>
                <li>✓ Foreign key relationships working correctly</li>
                <li>✓ No duplicate client data in sessions table</li>
              </ul>
            </div>

            <button
              onClick={testConnection}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors duration-200"
            >
              Test Again
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ConnectionTest;