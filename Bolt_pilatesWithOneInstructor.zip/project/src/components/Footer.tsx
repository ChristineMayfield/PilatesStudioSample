import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-sage-800 text-white py-8">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          {/* Bottom Bar - Only copyright and wellness message */}
          <div className="text-center text-sage-300">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <p className="text-sm">
                © 2024 Studio Serenity. All rights reserved.
              </p>
              <p className="text-sm">
                Dedicated to your wellness journey through authentic Pilates practice.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;