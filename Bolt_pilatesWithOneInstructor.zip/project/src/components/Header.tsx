import React, { useState, useEffect } from 'react';
import { Menu, X, LogOut, User, Edit3, Shield } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import LoginModal from './LoginModal';
import UserProfileModal from './UserProfileModal';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showUserModal, setShowUserModal] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showFloatingMenu, setShowFloatingMenu] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const location = useLocation();
  const { user, signOut } = useAuth();

  // Handle scroll behavior
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Show floating menu when scrolled down more than 100px
      if (currentScrollY > 100) {
        setShowFloatingMenu(true);
        // Hide main header when scrolling down, show when scrolling up
        if (currentScrollY > lastScrollY) {
          setIsScrolled(true); // Hide header
        } else {
          setIsScrolled(false); // Show header
        }
      } else {
        setShowFloatingMenu(false);
        setIsScrolled(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const scrollToSection = (sectionId: string) => {
    if (location.pathname !== '/') {
      // If not on home page, navigate to home first
      window.location.href = `/#${sectionId}`;
      return;
    }
    
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    setIsMenuOpen(false);
    setShowUserModal(false);
  };

  const handleLoginClick = () => {
    setShowLoginModal(true);
    setIsMenuOpen(false);
  };

  const handleUserClick = () => {
    setShowUserModal(true);
    setIsMenuOpen(false);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase())
      .slice(0, 2)
      .join('');
  };

  const toggleFloatingMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeFloatingMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <>
      {/* Main Header - slides up/down based on scroll */}
      <header className={`fixed top-0 left-0 right-0 z-40 bg-sage-800 shadow-lg transition-transform duration-300 ${
        isScrolled ? '-translate-y-full' : 'translate-y-0'
      }`}>
        <nav className="container mx-auto px-4 sm:px-6 flex items-center justify-between h-16 lg:h-20">
          <Link to="/" className="font-serif text-xl sm:text-2xl font-bold text-white">
            Studio Serenity
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4 lg:space-x-8">
            <button
              onClick={() => scrollToSection('about')}
              className="text-sm lg:text-base font-medium text-white hover:text-sage-200 transition-colors duration-200 px-2 py-1"
            >
              About
            </button>
            <Link
              to="/blog"
              className="text-sm lg:text-base font-medium text-white hover:text-sage-200 transition-colors duration-200 px-2 py-1"
            >
              Blog
            </Link>
            
            {/* Only show Client Portal if user is logged in */}
            {user && (
              <Link
                to="/client-booking"
                className="text-sm lg:text-base font-medium text-white hover:text-sage-200 transition-colors duration-200 px-2 py-1"
              >
                Client Portal
              </Link>
            )}
            
            <Link
              to="/pricing"
              className="text-sm lg:text-base font-medium text-white hover:text-sage-200 transition-colors duration-200 px-2 py-1"
            >
              Pricing
            </Link>
            <Link
              to="/contact"
              className="text-sm lg:text-base font-medium text-white hover:text-sage-200 transition-colors duration-200 px-2 py-1"
            >
              Contact
            </Link>
            
            {/* Only show Admin if user is logged in and is admin */}
            {user && user.admin && (
              <Link
                to="/admin"
                className="text-sm lg:text-base font-medium text-white hover:text-sage-200 transition-colors duration-200 px-2 py-1"
              >
                Admin
              </Link>
            )}
            
            {/* User Authentication */}
            <div className="flex items-center ml-4">
              {user ? (
                /* User Avatar - Click to open profile modal */
                <button
                  onClick={handleUserClick}
                  className="w-8 h-8 lg:w-10 lg:h-10 bg-white text-sage-800 rounded-full flex items-center justify-center font-semibold text-xs lg:text-sm hover:bg-sage-100 transition-colors duration-200"
                  title="View Profile"
                >
                  {getInitials(user.name)}
                </button>
              ) : (
                /* Login Icon */
                <button
                  onClick={handleLoginClick}
                  className="w-8 h-8 lg:w-10 lg:h-10 bg-white/20 hover:bg-white/30 text-white rounded-full flex items-center justify-center transition-colors duration-200"
                  title="Sign In"
                >
                  <User className="w-4 h-4 lg:w-5 lg:h-5" />
                </button>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className="w-6 h-6 text-white" />
            ) : (
              <Menu className="w-6 h-6 text-white" />
            )}
          </button>
        </nav>

        {/* Mobile Navigation - only show when main header is visible */}
        {isMenuOpen && !isScrolled && (
          <div className="md:hidden bg-sage-800 shadow-lg border-t border-sage-700">
            <div className="px-6 py-4 space-y-4">
              <button
                onClick={() => scrollToSection('about')}
                className="block w-full text-left font-medium text-white hover:text-sage-200 transition-colors duration-200 py-2"
              >
                About
              </button>
              <Link
                to="/blog"
                onClick={() => setIsMenuOpen(false)}
                className="block w-full text-left font-medium text-white hover:text-sage-200 transition-colors duration-200 py-2"
              >
                Blog
              </Link>
              
              {/* Only show Client Portal if user is logged in */}
              {user && (
                <Link
                  to="/client-booking"
                  onClick={() => setIsMenuOpen(false)}
                  className="block w-full text-left font-medium text-white hover:text-sage-200 transition-colors duration-200 py-2"
                >
                  Client Portal
                </Link>
              )}
              
              <Link
                to="/pricing"
                onClick={() => setIsMenuOpen(false)}
                className="block w-full text-left font-medium text-white hover:text-sage-200 transition-colors duration-200 py-2"
              >
                Pricing
              </Link>
              <Link
                to="/contact"
                onClick={() => setIsMenuOpen(false)}
                className="block w-full text-left font-medium text-white hover:text-sage-200 transition-colors duration-200 py-2"
              >
                Contact
              </Link>
              
              {/* Only show Admin if user is logged in and is admin */}
              {user && user.admin && (
                <Link
                  to="/admin"
                  onClick={() => setIsMenuOpen(false)}
                  className="block w-full text-left font-medium text-white hover:text-sage-200 transition-colors duration-200 py-2"
                >
                  Admin
                </Link>
              )}
              
              {/* Mobile User Menu */}
              {user ? (
                <div className="border-t border-sage-700 pt-4 space-y-4">
                  <button
                    onClick={handleUserClick}
                    className="flex items-center space-x-3 w-full text-left"
                  >
                    <div className="w-10 h-10 bg-white text-sage-800 rounded-full flex items-center justify-center font-semibold text-sm">
                      {getInitials(user.name)}
                    </div>
                    <div>
                      <span className="text-sm font-medium text-white block">
                        {user.name}
                      </span>
                      <span className="text-xs text-sage-200">
                        View Profile
                      </span>
                    </div>
                  </button>
                </div>
              ) : (
                <div className="border-t border-sage-700 pt-4">
                  <button
                    onClick={handleLoginClick}
                    className="flex items-center space-x-2 text-white hover:text-sage-200 transition-colors duration-200 py-2"
                  >
                    <User className="w-4 h-4" />
                    <span className="text-sm font-medium">Sign In</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Floating Hamburger Menu - appears when scrolled */}
      {showFloatingMenu && (
        <div className="fixed top-4 right-4 z-50">
          <button
            onClick={toggleFloatingMenu}
            className="w-12 h-12 bg-sage-800 hover:bg-sage-700 text-white rounded-full shadow-lg flex items-center justify-center transition-all duration-300 hover:scale-110"
            aria-label="Menu"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>

          {/* Floating Menu Dropdown */}
          {isMenuOpen && (
            <>
              {/* Backdrop */}
              <div 
                className="fixed inset-0 bg-black bg-opacity-20 z-40"
                onClick={closeFloatingMenu}
              ></div>
              
              {/* Menu Content */}
              <div className="absolute top-16 right-0 bg-white rounded-xl shadow-2xl border border-gray-200 min-w-[200px] z-50 overflow-hidden">
                <div className="py-2">
                  <button
                    onClick={() => {
                      scrollToSection('about');
                      closeFloatingMenu();
                    }}
                    className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                  >
                    About
                  </button>
                  <Link
                    to="/blog"
                    onClick={closeFloatingMenu}
                    className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                  >
                    Blog
                  </Link>
                  
                  {/* Only show Client Portal if user is logged in */}
                  {user && (
                    <Link
                      to="/client-booking"
                      onClick={closeFloatingMenu}
                      className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                    >
                      Client Portal
                    </Link>
                  )}
                  
                  <Link
                    to="/pricing"
                    onClick={closeFloatingMenu}
                    className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                  >
                    Pricing
                  </Link>
                  <Link
                    to="/contact"
                    onClick={closeFloatingMenu}
                    className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                  >
                    Contact
                  </Link>
                  
                  {/* Only show Admin if user is logged in and is admin */}
                  {user && user.admin && (
                    <Link
                      to="/admin"
                      onClick={closeFloatingMenu}
                      className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                    >
                      Admin
                    </Link>
                  )}
                  
                  {/* User Section */}
                  {user ? (
                    <div className="border-t border-gray-200 mt-2 pt-2">
                      <button
                        onClick={() => {
                          handleUserClick();
                          closeFloatingMenu();
                        }}
                        className="flex items-center space-x-3 w-full px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                      >
                        <div className="w-8 h-8 bg-sage-600 text-white rounded-full flex items-center justify-center font-semibold text-xs">
                          {getInitials(user.name)}
                        </div>
                        <div className="text-left">
                          <div className="font-medium text-sm">{user.name}</div>
                          <div className="text-xs text-gray-500">View Profile</div>
                        </div>
                      </button>
                    </div>
                  ) : (
                    <div className="border-t border-gray-200 mt-2 pt-2">
                      <button
                        onClick={() => {
                          handleLoginClick();
                          closeFloatingMenu();
                        }}
                        className="flex items-center space-x-3 w-full px-4 py-3 text-gray-700 hover:bg-sage-50 hover:text-sage-700 transition-colors duration-200"
                      >
                        <User className="w-5 h-5" />
                        <span className="font-medium">Sign In</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Login Modal */}
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)} 
      />

      {/* User Profile Modal */}
      {user && (
        <UserProfileModal
          isOpen={showUserModal}
          onClose={() => setShowUserModal(false)}
          user={user}
          onSignOut={handleSignOut}
        />
      )}
    </>
  );
};

export default Header;