import React from 'react';

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center justify-center bg-gradient-to-br from-sage-100 to-beige-100 overflow-hidden mt-16 lg:mt-20">
      <div className="absolute inset-0 bg-black/20"></div>
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          // Replace this URL with your own image URL
          backgroundImage: 'url("https://threeoneogirl.com/SeparatePage/images/secondPic.jpg")'
        }}
      ></div>
      
      <div className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto">
        <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
          Transform Your Body,
          <br />
          <span className="text-sage-200">Elevate Your Mind</span>
        </h1>
        
        <p className="text-lg sm:text-xl md:text-2xl mb-8 leading-relaxed opacity-90 max-w-3xl mx-auto">
          Experience the authentic Basi method of Pilates in a serene, private studio setting. 
          Discover your strongest, most confident self through personalized instruction and mindful movement.
        </p>
      </div>
    </section>
  );
};

export default Hero;