import React from 'react';
import { useAuth } from '../hooks/useAuth';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-white min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sage-600 mx-auto mb-4"></div>
            <p className="text-xl text-gray-600">Loading...</p>
          </div>
        </section>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-sage-50 min-h-screen flex items-center justify-center">
          <div className="text-center max-w-md">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Sign In Required</h2>
            <p className="text-gray-600 mb-6">
              Please sign in to access the client booking portal.
            </p>
            <p className="text-sm text-gray-500">
              Click the person icon in the header to sign in or create an account.
            </p>
          </div>
        </section>
      </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedRoute;