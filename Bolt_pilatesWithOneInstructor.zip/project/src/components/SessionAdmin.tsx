import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Plus, AlertTriangle, CheckCircle, ChevronLeft, ChevronRight, X, Save, Trash2 } from 'lucide-react';
import { useSupabaseSessionsAdmin, CreateSessionData, SessionConflict } from '../hooks/useSupabaseSessionsAdmin';

interface SessionWithClient {
  id: string;
  date: string;
  time: string;
  status: string;
  duration_minutes: number;
  notes?: string;
  client?: {
    id: string;
    name: string;
    email: string;
  };
}

const SessionAdmin = () => {
  const { 
    loading, 
    error, 
    checkSessionConflicts, 
    createSessions, 
    getAllSessionsWithClients,
    updateSessionStatus,
    deleteSession
  } = useSupabaseSessionsAdmin();

  const [sessions, setSessions] = useState<SessionWithClient[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [conflicts, setConflicts] = useState<SessionConflict[]>([]);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [pendingSessions, setPendingSessions] = useState<CreateSessionData[]>([]);
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('calendar');
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedSession, setSelectedSession] = useState<SessionWithClient | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editFormData, setEditFormData] = useState({
    status: '',
    notes: '',
    duration_minutes: 60
  });

  // Form state for creating sessions
  const [formData, setFormData] = useState({
    startDate: '',
    endDate: '',
    times: [''],
    status: 'available' as const,
    duration: 60,
    notes: '',
    repeatWeekly: false,
    weekCount: 1
  });

  const statusOptions = [
    { value: 'blocked', label: 'Blocked', color: 'bg-red-500', textColor: 'text-red-800', bgColor: 'bg-red-100', borderColor: 'border-red-200' },
    { value: 'available', label: 'Available', color: 'bg-green-500', textColor: 'text-green-800', bgColor: 'bg-green-100', borderColor: 'border-green-200' },
    { value: 'pending_confirmation', label: 'Pending Confirmation', color: 'bg-yellow-500', textColor: 'text-yellow-800', bgColor: 'bg-yellow-100', borderColor: 'border-yellow-200' },
    { value: 'confirmed', label: 'Confirmed', color: 'bg-blue-500', textColor: 'text-blue-800', bgColor: 'bg-blue-100', borderColor: 'border-blue-200' },
    { value: 'completed', label: 'Completed', color: 'bg-gray-500', textColor: 'text-gray-800', bgColor: 'bg-gray-100', borderColor: 'border-gray-200' }
  ];

  const getStatusDisplay = (status: string) => {
    const option = statusOptions.find(opt => opt.value === status);
    return option || { value: status, label: status, color: 'bg-gray-500', textColor: 'text-gray-800', bgColor: 'bg-gray-100', borderColor: 'border-gray-200' };
  };

  // Helper function to format time with AM/PM
  const formatTimeWithAMPM = (time: string): string => {
    // If time already has AM/PM, return as is
    if (time.includes('AM') || time.includes('PM')) {
      return time;
    }
    
    // Parse time and add AM/PM
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  // Load sessions on component mount
  useEffect(() => {
    loadSessions();
  }, []);

  const loadSessions = async () => {
    const data = await getAllSessionsWithClients();
    setSessions(data);
  };

  // Calendar navigation
  const nextMonth = () => {
    const next = new Date(currentMonth);
    next.setMonth(next.getMonth() + 1);
    setCurrentMonth(next);
  };

  const prevMonth = () => {
    const prev = new Date(currentMonth);
    prev.setMonth(prev.getMonth() - 1);
    setCurrentMonth(prev);
  };

  const goToToday = () => {
    setCurrentMonth(new Date());
  };

  // Calendar helper functions
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getSessionsForDate = (date: Date): SessionWithClient[] => {
    const dateStr = date.toISOString().split('T')[0];
    return sessions.filter(session => session.date === dateStr);
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const addTimeSlot = () => {
    setFormData(prev => ({
      ...prev,
      times: [...prev.times, '']
    }));
  };

  const removeTimeSlot = (index: number) => {
    if (formData.times.length > 1) {
      setFormData(prev => ({
        ...prev,
        times: prev.times.filter((_, i) => i !== index)
      }));
    }
  };

  const updateTimeSlot = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      times: prev.times.map((time, i) => i === index ? value : time)
    }));
  };

  const generateSessionsToCreate = (): CreateSessionData[] => {
    const sessions: CreateSessionData[] = [];
    const startDate = new Date(formData.startDate);
    const endDate = new Date(formData.endDate);
    
    // Validate dates
    if (startDate > endDate) {
      return [];
    }

    const currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      formData.times.forEach(time => {
        if (time.trim()) {
          sessions.push({
            date: currentDate.toISOString().split('T')[0],
            time: time.trim(),
            status: formData.status,
            duration_minutes: formData.duration,
            notes: formData.notes || undefined
          });
        }
      });
      
      if (formData.repeatWeekly) {
        currentDate.setDate(currentDate.getDate() + 7);
      } else {
        currentDate.setDate(currentDate.getDate() + 1);
      }
    }

    return sessions;
  };

  const handleCheckConflicts = async () => {
    const sessionsToCreate = generateSessionsToCreate();
    
    if (sessionsToCreate.length === 0) {
      alert('Please fill in all required fields and ensure end date is after start date.');
      return;
    }

    const foundConflicts = await checkSessionConflicts(sessionsToCreate);
    setConflicts(foundConflicts);
    setPendingSessions(sessionsToCreate);
    setShowConfirmation(true);
  };

  const handleCreateSessions = async () => {
    const success = await createSessions(pendingSessions);
    
    if (success) {
      setShowCreateForm(false);
      setShowConfirmation(false);
      setConflicts([]);
      setPendingSessions([]);
      setFormData({
        startDate: '',
        endDate: '',
        times: [''],
        status: 'available',
        duration: 60,
        notes: '',
        repeatWeekly: false,
        weekCount: 1
      });
      await loadSessions();
    }
  };

  const handleSessionClick = (session: SessionWithClient) => {
    setSelectedSession(session);
    setEditFormData({
      status: session.status,
      notes: session.notes || '',
      duration_minutes: session.duration_minutes
    });
    setShowEditModal(true);
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSession) return;

    const success = await updateSessionStatus(selectedSession.id, editFormData.status);
    if (success) {
      setShowEditModal(false);
      setSelectedSession(null);
      await loadSessions();
    }
  };

  const handleDeleteSession = async () => {
    if (!selectedSession) return;
    
    if (window.confirm('Are you sure you want to delete this appointment?')) {
      const success = await deleteSession(selectedSession.id);
      if (success) {
        setShowEditModal(false);
        setSelectedSession(null);
        await loadSessions();
      }
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h3 className="font-serif text-2xl font-bold text-gray-800">Appointments</h3>
        <div className="flex items-center space-x-4">
          {/* View Toggle */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('calendar')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                viewMode === 'calendar'
                  ? 'bg-white text-sage-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Calendar
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                viewMode === 'list'
                  ? 'bg-white text-sage-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              List
            </button>
          </div>
          
          <button
            onClick={() => setShowCreateForm(true)}
            className="flex items-center bg-sage-600 hover:bg-sage-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors duration-200"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Appointments
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-300 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
            <span className="text-red-800">{error}</span>
          </div>
        </div>
      )}

      {/* Calendar View */}
      {viewMode === 'calendar' && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h4 className="font-semibold text-lg text-gray-800">Appointment Calendar</h4>
                <button
                  onClick={goToToday}
                  className="text-sm bg-sage-100 hover:bg-sage-200 text-sage-700 px-3 py-1 rounded-md transition-colors duration-200"
                >
                  Today
                </button>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={prevMonth}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors duration-200"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-600" />
                </button>
                <h4 className="text-xl font-semibold text-gray-800 min-w-[200px] text-center">
                  {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </h4>
                <button
                  onClick={nextMonth}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors duration-200"
                >
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>
            
            {/* Status Legend */}
            <div className="mt-4 flex flex-wrap items-center gap-4 text-sm">
              <span className="text-gray-600 font-medium">Status:</span>
              {statusOptions.map(status => (
                <div key={status.value} className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${status.color}`}></div>
                  <span className="text-gray-700">{status.label}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="p-6">
            {/* Day Headers */}
            <div className="grid grid-cols-7 gap-2 mb-4">
              {dayNames.map(day => (
                <div key={day} className="text-center text-sm font-medium text-gray-700 py-2">
                  {day}
                </div>
              ))}
            </div>
            
            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2">
              {getDaysInMonth(currentMonth).map((date, index) => {
                if (!date) {
                  return <div key={index} className="min-h-[140px]"></div>;
                }

                const daySessions = getSessionsForDate(date);
                const isToday = date.toDateString() === new Date().toDateString();

                return (
                  <div key={index} className="min-h-[140px]">
                    <div className={`h-full rounded-lg border transition-colors duration-200 ${
                      isToday 
                        ? 'border-sage-400 bg-sage-50' 
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}>
                      <div className="p-2">
                        <div className={`text-sm font-medium mb-2 ${
                          isToday ? 'text-sage-700' : 'text-gray-700'
                        }`}>
                          {date.getDate()}
                        </div>
                        
                        {/* Sessions for this day */}
                        <div className="space-y-1">
                          {daySessions.map((session) => {
                            const statusDisplay = getStatusDisplay(session.status);
                            return (
                              <button
                                key={session.id}
                                onClick={() => handleSessionClick(session)}
                                className={`w-full text-xs px-2 py-1 rounded transition-colors duration-200 font-medium border cursor-pointer hover:opacity-80 ${
                                  statusDisplay.bgColor
                                } ${statusDisplay.textColor} ${statusDisplay.borderColor}`}
                                title={`${formatTimeWithAMPM(session.time)} - ${statusDisplay.label}${session.client ? ` (${session.client.name})` : ''}`}
                              >
                                <div className="truncate">
                                  {formatTimeWithAMPM(session.time)}
                                </div>
                                {session.client && (
                                  <div className="text-xs opacity-75 truncate">
                                    {session.client.name}
                                  </div>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h4 className="font-semibold text-lg text-gray-800">All Appointments</h4>
            <p className="text-gray-600 text-sm">Manage existing appointments and their status</p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sessions.map((session) => {
                  const statusDisplay = getStatusDisplay(session.status);
                  return (
                    <tr 
                      key={session.id} 
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleSessionClick(session)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {new Date(session.date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatTimeWithAMPM(session.time)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full ${statusDisplay.bgColor} ${statusDisplay.textColor}`}>
                          <div className={`w-2 h-2 rounded-full ${statusDisplay.color} mr-2`}></div>
                          {statusDisplay.label}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {session.client ? session.client.name : '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {session.duration_minutes} min
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            
            {sessions.length === 0 && !loading && (
              <div className="text-center py-8 text-gray-500">
                No appointments found. Create some appointments to get started.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Session Modal */}
      {showEditModal && selectedSession && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-serif text-2xl font-bold text-gray-800">Edit Appointment</h3>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="bg-sage-50 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-gray-800 mb-2">Appointment Details:</h4>
                <p className="text-gray-600">
                  <strong>Date:</strong> {new Date(selectedSession.date).toLocaleDateString()} <br />
                  <strong>Time:</strong> {formatTimeWithAMPM(selectedSession.time)} <br />
                  <strong>Duration:</strong> {selectedSession.duration_minutes} minutes <br />
                  <strong>Client:</strong> {selectedSession.client?.name || 'No client assigned'}
                </p>
              </div>

              <form onSubmit={handleEditSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Status *
                  </label>
                  <select
                    value={editFormData.status}
                    onChange={(e) => setEditFormData(prev => ({ ...prev, status: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                    required
                  >
                    {statusOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Notes
                  </label>
                  <textarea
                    value={editFormData.notes}
                    onChange={(e) => setEditFormData(prev => ({ ...prev, notes: e.target.value }))}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 resize-none"
                    placeholder="Any notes about this appointment..."
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    type="button"
                    onClick={() => setShowEditModal(false)}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-3 rounded-full font-semibold transition-colors duration-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleDeleteSession}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full font-semibold transition-colors duration-300 flex items-center justify-center"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-sage-600 hover:bg-sage-700 text-white px-6 py-3 rounded-full font-semibold transition-colors duration-300 flex items-center justify-center"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Create Sessions Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-serif text-2xl font-bold text-gray-800">Create Appointments</h3>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-6">
                {/* Date Range */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Start Date *
                    </label>
                    <input
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      End Date *
                    </label>
                    <input
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                      required
                    />
                  </div>
                </div>

                {/* Repeat Options */}
                <div className="flex items-center space-x-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.repeatWeekly}
                      onChange={(e) => setFormData(prev => ({ ...prev, repeatWeekly: e.target.checked }))}
                      className="mr-2 rounded border-gray-300 text-sage-600 focus:ring-sage-500"
                    />
                    <span className="text-sm font-medium text-gray-700">Repeat Weekly</span>
                  </label>
                </div>

                {/* Time Slots */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-sm font-medium text-gray-700">
                      Time Slots *
                    </label>
                    <button
                      type="button"
                      onClick={addTimeSlot}
                      className="text-sage-600 hover:text-sage-700 text-sm font-medium"
                    >
                      + Add Time
                    </button>
                  </div>
                  <div className="space-y-2">
                    {formData.times.map((time, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <input
                          type="time"
                          value={time}
                          onChange={(e) => updateTimeSlot(index, e.target.value)}
                          className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                          required
                        />
                        {formData.times.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeTimeSlot(index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status and Duration */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status *
                    </label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as any }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                    >
                      {statusOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Duration (minutes)
                    </label>
                    <input
                      type="number"
                      value={formData.duration}
                      onChange={(e) => setFormData(prev => ({ ...prev, duration: parseInt(e.target.value) || 60 }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                      min="15"
                      max="180"
                    />
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Notes (Optional)
                  </label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 resize-none"
                    placeholder="Any additional notes for these appointments..."
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-3 rounded-full font-semibold transition-colors duration-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleCheckConflicts}
                    disabled={loading}
                    className="flex-1 bg-sage-600 hover:bg-sage-700 text-white px-6 py-3 rounded-full font-semibold transition-colors duration-300 disabled:opacity-50"
                  >
                    {loading ? 'Checking...' : 'Check & Create'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-serif text-2xl font-bold text-gray-800">Confirm Appointment Creation</h3>
                <button
                  onClick={() => setShowConfirmation(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {conflicts.length > 0 ? (
                <div className="space-y-4">
                  <div className="bg-red-50 border border-red-300 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
                      <h4 className="font-semibold text-red-800">Conflicts Found</h4>
                    </div>
                    <p className="text-red-700 mb-4">
                      The following time slots already have appointments scheduled:
                    </p>
                    <div className="space-y-2">
                      {conflicts.map((conflict, index) => (
                        <div key={index} className="bg-white rounded p-3 border border-red-200">
                          <p className="font-medium text-gray-800">
                            {new Date(conflict.date).toLocaleDateString()} at {formatTimeWithAMPM(conflict.time)}
                          </p>
                          <p className="text-sm text-gray-600">
                            Status: <span className="font-medium">{conflict.status}</span>
                            {conflict.client_name && (
                              <span> • Client: {conflict.client_name}</span>
                            )}
                          </p>
                        </div>
                      ))}
                    </div>
                    <p className="text-red-700 mt-4 text-sm">
                      Please adjust your appointment times or dates to avoid these conflicts.
                    </p>
                  </div>
                  <button
                    onClick={() => setShowConfirmation(false)}
                    className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-3 rounded-full font-semibold transition-colors duration-300"
                  >
                    Go Back and Adjust
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-300 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                      <h4 className="font-semibold text-green-800">No Conflicts Found</h4>
                    </div>
                    <p className="text-green-700 mb-4">
                      Ready to create {pendingSessions.length} appointment(s) with status "{formData.status}".
                    </p>
                    <div className="bg-white rounded p-3 border border-green-200 max-h-40 overflow-y-auto">
                      {pendingSessions.map((session, index) => (
                        <div key={index} className="text-sm text-gray-600 py-1">
                          {new Date(session.date).toLocaleDateString()} at {formatTimeWithAMPM(session.time)}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <button
                      onClick={() => setShowConfirmation(false)}
                      className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-3 rounded-full font-semibold transition-colors duration-300"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleCreateSessions}
                      disabled={loading}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full font-semibold transition-colors duration-300 disabled:opacity-50"
                    >
                      {loading ? 'Creating...' : 'Create Appointments'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SessionAdmin;