import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

const Studio = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const images = [
    {
      src: "https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      alt: "Main studio space with reformer equipment"
    },
    {
      src: "https://images.pexels.com/photos/4056535/pexels-photo-4056535.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      alt: "Private session in progress"
    },
    {
      src: "https://images.pexels.com/photos/4498597/pexels-photo-4498597.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      alt: "Pilates equipment and accessories"
    },
    {
      src: "https://images.pexels.com/photos/4498592/pexels-photo-4498592.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      alt: "Stretching and alignment work"
    },
    {
      src: "https://images.pexels.com/photos/4498591/pexels-photo-4498591.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      alt: "Peaceful studio atmosphere"
    },
    {
      src: "https://images.pexels.com/photos/4498590/pexels-photo-4498590.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      alt: "Modern pilates studio interior"
    }
  ];

  const openLightbox = (index: number) => {
    setSelectedImage(index);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const navigateLightbox = (direction: 'prev' | 'next') => {
    if (selectedImage === null) return;
    
    let newIndex;
    if (direction === 'prev') {
      newIndex = selectedImage === 0 ? images.length - 1 : selectedImage - 1;
    } else {
      newIndex = selectedImage === images.length - 1 ? 0 : selectedImage + 1;
    }
    setSelectedImage(newIndex);
  };

  return (
    <section id="studio" className="py-20 bg-sage-50">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              Studio Gallery
            </h2>
            <div className="w-24 h-1 bg-sage-600 mx-auto mb-8"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Step into our serene, fully-equipped studio designed to provide the perfect environment 
              for your Pilates practice. Every detail has been carefully considered to ensure your comfort and focus.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {images.map((image, index) => (
              <div
                key={index}
                className="relative group cursor-pointer overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() => openLightbox(index)}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-white text-center">
                    <p className="font-semibold">View Full Size</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl p-8 md:p-12 shadow-lg">
            <h3 className="font-serif text-3xl font-bold text-gray-800 mb-6 text-center">
              Studio Features
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="text-center">
                <h4 className="font-semibold text-xl text-sage-800 mb-3">Professional Equipment</h4>
                <p className="text-gray-600">State-of-the-art Pilates reformers, cadillac, and accessories for comprehensive training.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-xl text-sage-800 mb-3">Private Setting</h4>
                <p className="text-gray-600">Intimate, one-on-one sessions in a peaceful environment free from distractions.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-xl text-sage-800 mb-3">Natural Light</h4>
                <p className="text-gray-600">Large windows provide abundant natural light, creating an uplifting atmosphere.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-xl text-sage-800 mb-3">Climate Controlled</h4>
                <p className="text-gray-600">Comfortable temperature year-round for optimal movement and relaxation.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-xl text-sage-800 mb-3">Sound System</h4>
                <p className="text-gray-600">High-quality audio for guided instruction and soothing background music.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-xl text-sage-800 mb-3">Amenities</h4>
                <p className="text-gray-600">Changing area, water station, and comfortable seating for pre and post-session.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage !== null && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
          
          <button
            onClick={() => navigateLightbox('prev')}
            className="absolute left-4 text-white hover:text-gray-300 transition-colors"
          >
            <ChevronLeft className="w-8 h-8" />
          </button>
          
          <button
            onClick={() => navigateLightbox('next')}
            className="absolute right-4 text-white hover:text-gray-300 transition-colors"
          >
            <ChevronRight className="w-8 h-8" />
          </button>
          
          <img
            src={images[selectedImage].src}
            alt={images[selectedImage].alt}
            className="max-w-full max-h-full object-contain"
          />
          
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-white text-center">
            <p className="text-lg font-medium">{images[selectedImage].alt}</p>
            <p className="text-sm opacity-75">{selectedImage + 1} of {images.length}</p>
          </div>
        </div>
      )}
    </section>
  );
};

export default Studio;