import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const Testimonials = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      name: "Emma Thompson",
      location: "Downtown Professional",
      image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      text: "Sarah's expertise in the Basi method has completely transformed my relationship with movement. After years of back pain from desk work, I now feel stronger and more aligned than ever. Her attention to detail and personalized approach makes every session valuable.",
      rating: 5
    },
    {
      name: "Michael Rodriguez",
      location: "Former Athlete",
      image: "https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      text: "As a former college basketball player dealing with old injuries, I was skeptical about Pilates. Sarah's method has not only helped me recover but has given me better body awareness than I ever had as an athlete. The private sessions are incredibly effective.",
      rating: 5
    },
    {
      name: "Lisa Chen",
      location: "Busy Mother of Two",
      image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      text: "Finding time for myself as a mom is challenging, but Sarah makes every minute count. Her studio is my sanctuary, and the progress I've made in just six months is remarkable. I feel stronger, more confident, and have better posture than before having kids.",
      rating: 5
    },
    {
      name: "Robert Wilson",
      location: "Senior Executive",
      image: "https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      text: "At 55, I thought my days of feeling physically capable were behind me. Sarah's patient instruction and the Basi method have proven me wrong. I've regained flexibility I lost decades ago and feel more energetic in my daily life. Highly recommend to anyone.",
      rating: 5
    },
    {
      name: "Amanda Foster",
      location: "Yoga Instructor",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      text: "Even as a yoga instructor, I needed something more targeted for my core and alignment issues. Sarah's Pilates sessions complement my yoga practice perfectly. Her knowledge of anatomy and movement is exceptional, and I always learn something new.",
      rating: 5
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToTestimonial = (index: number) => {
    setCurrentTestimonial(index);
  };

  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              Client Stories
            </h2>
            <div className="w-24 h-1 bg-sage-600 mx-auto mb-8"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Hear from clients who have transformed their lives through personalized Pilates instruction 
              and the proven Basi method.
            </p>
          </div>

          <div className="relative bg-beige-50 rounded-2xl p-8 md:p-12 overflow-hidden">
            <div className="relative z-10">
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="lg:w-1/3 text-center">
                  <img
                    src={testimonials[currentTestimonial].image}
                    alt={testimonials[currentTestimonial].name}
                    className="w-32 h-32 rounded-full mx-auto mb-4 object-cover shadow-lg"
                  />
                  <h4 className="font-semibold text-xl text-gray-800">
                    {testimonials[currentTestimonial].name}
                  </h4>
                  <p className="text-sage-600 mb-4">{testimonials[currentTestimonial].location}</p>
                  <div className="flex justify-center space-x-1">
                    {[...Array(testimonials[currentTestimonial].rating)].map((_, index) => (
                      <Star key={index} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
                
                <div className="lg:w-2/3">
                  <blockquote className="text-lg md:text-xl text-gray-700 leading-relaxed italic mb-6">
                    "{testimonials[currentTestimonial].text}"
                  </blockquote>
                </div>
              </div>
            </div>

            <button
              onClick={prevTestimonial}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white hover:bg-gray-50 rounded-full p-2 shadow-lg transition-colors duration-200"
            >
              <ChevronLeft className="w-6 h-6 text-gray-600" />
            </button>
            
            <button
              onClick={nextTestimonial}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white hover:bg-gray-50 rounded-full p-2 shadow-lg transition-colors duration-200"
            >
              <ChevronRight className="w-6 h-6 text-gray-600" />
            </button>
          </div>

          <div className="flex justify-center mt-8 space-x-3">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => goToTestimonial(index)}
                className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                  index === currentTestimonial ? 'bg-sage-600' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>

          {/* Removed the extra spacing here - changed from mt-16 to mt-6 */}
          <div className="mt-6 bg-gradient-to-r from-sage-600 to-sage-700 rounded-2xl p-8 md:p-12 text-center text-white">
            <h3 className="font-serif text-3xl md:text-4xl font-bold mb-4">
              Your Transformation Awaits
            </h3>
            <p className="text-xl mb-8 max-w-3xl mx-auto leading-relaxed opacity-90">
              Join hundreds of clients who have discovered their strongest, most confident selves through 
              personalized Pilates instruction. Your journey to better movement, posture, and wellness 
              starts with a single session.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;