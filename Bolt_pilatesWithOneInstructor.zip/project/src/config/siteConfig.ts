// Site Configuration - Single source of truth for all variable content
export interface PricingPackage {
  name: string;
  price: string;
  originalPrice?: string;
  description: string;
  features: string[];
  popular: boolean;
  buttonText: string;
}

export interface AddOnService {
  name: string;
  price: string;
  description: string;
}

export interface StudioHours {
  monday: string;
  tuesday: string;
  wednesday: string;
  thursday: string;
  friday: string;
  saturday: string;
  sunday: string;
}

export interface SiteConfig {
  consultationFee: string;
  pricingPackages: PricingPackage[];
  addOnServices: AddOnService[];
  studioHours: StudioHours;
}

// Default configuration
export const defaultSiteConfig: SiteConfig = {
  consultationFee: "$75",
  pricingPackages: [
    {
      name: "Single Session",
      price: "$95",
      description: "Perfect for trying out our services",
      features: [
        "60-minute private session",
        "Personalized assessment",
        "Equipment instruction",
        "Take-home exercises",
        "Progress tracking"
      ],
      popular: false,
      buttonText: "Book Single Session"
    },
    {
      name: "Starter Package",
      price: "$360",
      originalPrice: "$380",
      description: "Ideal for building foundation (4 sessions)",
      features: [
        "Four 60-minute sessions",
        "Comprehensive body assessment",
        "Customized program design",
        "Technique refinement",
        "Flexible scheduling",
        "Progress evaluation"
      ],
      popular: true,
      buttonText: "Start Your Journey"
    },
    {
      name: "Transformation Package",
      price: "$850",
      originalPrice: "$950",
      description: "Complete wellness transformation (10 sessions)",
      features: [
        "Ten 60-minute sessions",
        "In-depth postural analysis",
        "Goal-specific programming",
        "Nutritional guidance",
        "Home practice routines",
        "Ongoing support",
        "Achievement celebration"
      ],
      popular: false,
      buttonText: "Transform Your Body"
    }
  ],
  addOnServices: [
    {
      name: "Extended Session",
      price: "$125",
      description: "90-minute intensive session for deeper work"
    },
    {
      name: "Couples Session",
      price: "$160",
      description: "60-minute shared session for partners"
    },
    {
      name: "Virtual Consultation",
      price: "$45",
      description: "30-minute online movement assessment"
    }
  ],
  studioHours: {
    monday: "7:00 AM - 7:00 PM",
    tuesday: "7:00 AM - 7:00 PM",
    wednesday: "7:00 AM - 7:00 PM",
    thursday: "7:00 AM - 7:00 PM",
    friday: "7:00 AM - 7:00 PM",
    saturday: "8:00 AM - 4:00 PM",
    sunday: "9:00 AM - 3:00 PM"
  }
};