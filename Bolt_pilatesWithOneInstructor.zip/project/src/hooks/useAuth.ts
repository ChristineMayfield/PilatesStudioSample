import { useState, useEffect, createContext, useContext } from 'react';
import { supabase } from '../lib/supabase';

interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  experience_level?: string;
  goals?: string;
  injuries?: string;
  sessions_remaining: number;
  admin: boolean;
  created_at: string;
  updated_at: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUp: (email: string, password: string, userData: any) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useAuthProvider = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session in localStorage
    const checkExistingSession = () => {
      const storedUser = localStorage.getItem('auth_user');
      if (storedUser) {
        try {
          const userData = JSON.parse(storedUser);
          setUser(userData);
        } catch (error) {
          console.error('Error parsing stored user data:', error);
          localStorage.removeItem('auth_user');
        }
      }
      setLoading(false);
    };

    checkExistingSession();
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true);

      // Query the clients table for matching email and password
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('email', email)
        .eq('password', password)
        .single();

      if (error || !data) {
        return { success: false, error: 'Invalid email or password' };
      }

      // Store user data in localStorage and state
      const userData: User = {
        id: data.id,
        email: data.email,
        name: data.name,
        phone: data.phone,
        experience_level: data.experience_level,
        goals: data.goals,
        injuries: data.injuries,
        sessions_remaining: data.sessions_remaining,
        admin: data.admin || false,
        created_at: data.created_at,
        updated_at: data.updated_at
      };

      localStorage.setItem('auth_user', JSON.stringify(userData));
      setUser(userData);

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, userData: any) => {
    try {
      setLoading(true);

      // Check if email already exists
      const { data: existingUser } = await supabase
        .from('clients')
        .select('email')
        .eq('email', email)
        .single();

      if (existingUser) {
        return { success: false, error: 'An account with this email already exists' };
      }

      // Create new client record
      const { data, error } = await supabase
        .from('clients')
        .insert({
          name: userData.name,
          email: email,
          phone: userData.phone,
          password: password,
          experience_level: userData.experience_level,
          goals: userData.goals,
          injuries: userData.injuries,
          sessions_remaining: 0,
          admin: false
        })
        .select()
        .single();

      if (error) {
        return { success: false, error: error.message };
      }

      // Auto sign in the new user
      const newUser: User = {
        id: data.id,
        email: data.email,
        name: data.name,
        phone: data.phone,
        experience_level: data.experience_level,
        goals: data.goals,
        injuries: data.injuries,
        sessions_remaining: data.sessions_remaining,
        admin: data.admin || false,
        created_at: data.created_at,
        updated_at: data.updated_at
      };

      localStorage.setItem('auth_user', JSON.stringify(newUser));
      setUser(newUser);

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    localStorage.removeItem('auth_user');
    setUser(null);
  };

  const resetPassword = async (email: string) => {
    try {
      // Check if user exists
      const { data, error } = await supabase
        .from('clients')
        .select('email, name')
        .eq('email', email)
        .single();

      if (error || !data) {
        return { success: false, error: 'No account found with this email address' };
      }

      // For now, just reset password to 'password'
      // In a real app, you'd generate a secure token and send an email
      const { error: updateError } = await supabase
        .from('clients')
        .update({ password: 'password' })
        .eq('email', email);

      if (updateError) {
        return { success: false, error: 'Failed to reset password' };
      }

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  };

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    resetPassword,
  };
};

export { AuthContext };