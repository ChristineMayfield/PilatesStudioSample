import { useSupabaseConfig } from './useSupabaseConfig';

// This hook now uses Supabase as the primary data source
// but falls back to localStorage for offline functionality
export const useConfig = () => {
  return useSupabaseConfig();
};