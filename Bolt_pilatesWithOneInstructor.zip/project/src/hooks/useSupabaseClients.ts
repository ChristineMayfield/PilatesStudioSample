import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  experience_level?: string;
  goals?: string;
  injuries?: string;
  package_type?: string;
  sessions_remaining: number;
  created_at: string;
  updated_at: string;
}

export interface NewClientData {
  name: string;
  email: string;
  phone: string;
  experience_level?: string;
  goals?: string;
  injuries?: string;
}

export const useSupabaseClients = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load all clients from Supabase
  const loadClients = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .order('name', { ascending: true });

      if (error) {
        console.error('Error loading clients:', error);
        setError('Failed to load clients');
        return;
      }

      setClients(data || []);
    } catch (err) {
      console.error('Error loading clients:', err);
      setError('Failed to load clients');
    } finally {
      setLoading(false);
    }
  };

  // Search clients by name
  const searchClients = (query: string): Client[] => {
    if (!query.trim()) return [];
    
    const searchTerm = query.toLowerCase();
    return clients.filter(client => 
      client.name.toLowerCase().includes(searchTerm) ||
      client.email.toLowerCase().includes(searchTerm)
    );
  };

  // Create a new client
  const createClient = async (clientData: NewClientData): Promise<Client | null> => {
    try {
      setError(null);

      const { data, error } = await supabase
        .from('clients')
        .insert({
          name: clientData.name,
          email: clientData.email,
          phone: clientData.phone,
          experience_level: clientData.experience_level,
          goals: clientData.goals,
          injuries: clientData.injuries,
          sessions_remaining: 0
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating client:', error);
        setError('Failed to create client');
        return null;
      }

      // Add the new client to our local state
      setClients(prev => [...prev, data]);
      return data;
    } catch (err) {
      console.error('Error creating client:', err);
      setError('Failed to create client');
      return null;
    }
  };

  // Get client by ID
  const getClientById = (id: string): Client | undefined => {
    return clients.find(client => client.id === id);
  };

  // Update client sessions remaining
  const updateClientSessions = async (clientId: string, sessionsRemaining: number): Promise<boolean> => {
    try {
      setError(null);

      const { error } = await supabase
        .from('clients')
        .update({ sessions_remaining: sessionsRemaining })
        .eq('id', clientId);

      if (error) {
        console.error('Error updating client sessions:', error);
        setError('Failed to update client sessions');
        return false;
      }

      // Update local state
      setClients(prev => prev.map(client => 
        client.id === clientId 
          ? { ...client, sessions_remaining: sessionsRemaining }
          : client
      ));

      return true;
    } catch (err) {
      console.error('Error updating client sessions:', err);
      setError('Failed to update client sessions');
      return false;
    }
  };

  useEffect(() => {
    loadClients();

    // Set up real-time subscription for client changes
    const subscription = supabase
      .channel('clients_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'clients'
        },
        () => {
          loadClients(); // Refresh clients when changes occur
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return {
    clients,
    loading,
    error,
    searchClients,
    createClient,
    getClientById,
    updateClientSessions,
    refetch: loadClients
  };
};