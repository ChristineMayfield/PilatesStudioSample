import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { SiteConfig, defaultSiteConfig } from '../config/siteConfig';

export const useSupabaseConfig = () => {
  const [config, setConfig] = useState<SiteConfig>(defaultSiteConfig);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load config from Supabase
  const loadConfig = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('site_config')
        .select('config_data')
        .order('id', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        console.error('Error loading config:', error);
        setError('Failed to load configuration');
        return;
      }

      if (data?.config_data) {
        setConfig(data.config_data as SiteConfig);
      }
    } catch (err) {
      console.error('Error loading config:', err);
      setError('Failed to load configuration');
    } finally {
      setLoading(false);
    }
  };

  // Save config to Supabase
  const updateConfig = async (newConfig: SiteConfig) => {
    try {
      setError(null);
      
      // First, try to update existing config
      const { data: existingData } = await supabase
        .from('site_config')
        .select('id')
        .limit(1)
        .single();

      if (existingData) {
        // Update existing config
        const { error } = await supabase
          .from('site_config')
          .update({ 
            config_data: newConfig,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingData.id);

        if (error) throw error;
      } else {
        // Insert new config
        const { error } = await supabase
          .from('site_config')
          .insert({ config_data: newConfig });

        if (error) throw error;
      }

      setConfig(newConfig);
      return true;
    } catch (err) {
      console.error('Error updating config:', err);
      setError('Failed to save configuration');
      return false;
    }
  };

  useEffect(() => {
    loadConfig();

    // Set up real-time subscription for config changes
    const subscription = supabase
      .channel('site_config_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'site_config'
        },
        (payload) => {
          if (payload.new && 'config_data' in payload.new) {
            setConfig(payload.new.config_data as SiteConfig);
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return {
    config,
    loading,
    error,
    updateConfig,
    refetch: loadConfig
  };
};