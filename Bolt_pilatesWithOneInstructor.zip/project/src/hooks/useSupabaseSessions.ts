import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface Session {
  id: string;
  date: string;
  time: string;
  duration_minutes: number;
  is_available: boolean;
  status: string;
  client_id?: string;
  session_type: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface BookingData {
  date: string;
  time: string;
  client_id: string;
  session_type: string;
  notes?: string;
}

export const useSupabaseSessions = () => {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load sessions from Supabase
  const loadSessions = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('sessions')
        .select('*')
        .order('date', { ascending: true })
        .order('time', { ascending: true });

      if (error) {
        console.error('❌ Error loading sessions:', error);
        setError('Failed to load sessions');
        return;
      }

      setSessions(data || []);
      setError(null);
    } catch (err) {
      console.error('❌ Error loading sessions:', err);
      setError('Failed to load sessions');
    } finally {
      setLoading(false);
    }
  };

  // Convert Date object to local date string (YYYY-MM-DD) without timezone conversion
  const dateToLocalString = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Get available sessions for a specific date
  // ONLY show sessions that exist in DB and have status = 'available'
  const getAvailableSlots = (date: Date): string[] => {
    const dateStr = dateToLocalString(date);
    
    // Skip past dates only
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (date < today) {
      return [];
    }

    // Get ALL sessions for this date from the database
    const dateSessions = sessions.filter(session => session.date === dateStr);
    
    // ONLY return sessions that exist in DB AND have status = 'available'
    const availableSlots = dateSessions
      .filter(session => session.status === 'available')
      .map(session => session.time);

    return availableSlots;
  };

  // Book a session
  const bookSession = async (bookingData: BookingData): Promise<boolean> => {
    try {
      setError(null);

      // Check if session already exists for this date/time
      const { data: existingSession } = await supabase
        .from('sessions')
        .select('id, status')
        .eq('date', bookingData.date)
        .eq('time', bookingData.time)
        .maybeSingle();

      if (existingSession) {
        if (existingSession.status !== 'available') {
          setError('This time slot is no longer available');
          return false;
        }

        // Update existing session to mark as confirmed
        const { error } = await supabase
          .from('sessions')
          .update({
            status: 'confirmed',
            client_id: bookingData.client_id,
            session_type: bookingData.session_type,
            notes: bookingData.notes
          })
          .eq('id', existingSession.id);

        if (error) {
          console.error('❌ Error updating session:', error);
          throw error;
        }
      } else {
        // Create new session as confirmed
        const { error } = await supabase
          .from('sessions')
          .insert({
            date: bookingData.date,
            time: bookingData.time,
            status: 'confirmed',
            client_id: bookingData.client_id,
            session_type: bookingData.session_type,
            notes: bookingData.notes
          });

        if (error) {
          console.error('❌ Error creating session:', error);
          throw error;
        }
      }

      // Reload sessions to get the latest data from the database
      await loadSessions();
      return true;
    } catch (err) {
      console.error('❌ Error booking session:', err);
      setError('Failed to book session');
      return false;
    }
  };

  // Create available time slots (admin function)
  const createAvailableSlots = async (date: string, times: string[]): Promise<boolean> => {
    try {
      setError(null);

      const sessionsToInsert = times.map(time => ({
        date,
        time,
        status: 'available',
        session_type: 'regular'
      }));

      const { error } = await supabase
        .from('sessions')
        .insert(sessionsToInsert);

      if (error) {
        console.error('❌ Error creating available slots:', error);
        throw error;
      }

      await loadSessions(); // Refresh sessions
      return true;
    } catch (err) {
      console.error('❌ Error creating available slots:', err);
      setError('Failed to create available slots');
      return false;
    }
  };

  // Get sessions with client information
  const getSessionsWithClients = async () => {
    try {
      const { data, error } = await supabase
        .from('sessions')
        .select(`
          *,
          client:clients(*)
        `)
        .order('date', { ascending: true })
        .order('time', { ascending: true });

      if (error) throw error;
      return data || [];
    } catch (err) {
      console.error('❌ Error loading sessions with clients:', err);
      return [];
    }
  };

  useEffect(() => {
    loadSessions();

    // Set up real-time subscription for session changes
    const subscription = supabase
      .channel('sessions_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'sessions'
        },
        () => {
          loadSessions(); // Refresh sessions when changes occur
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return {
    sessions,
    loading,
    error,
    getAvailableSlots,
    bookSession,
    createAvailableSlots,
    getSessionsWithClients,
    refetch: loadSessions,
    dateToLocalString // Export this helper function
  };
};