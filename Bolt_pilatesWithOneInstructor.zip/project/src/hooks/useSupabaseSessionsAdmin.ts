import { useState } from 'react';
import { supabase } from '../lib/supabase';

export interface SessionConflict {
  date: string;
  time: string;
  status: string;
  client_name?: string;
}

export interface CreateSessionData {
  date: string;
  time: string;
  status: 'blocked' | 'available' | 'pending_confirmation' | 'confirmed' | 'completed';
  duration_minutes?: number;
  notes?: string;
}

export interface CreateSessionsRequest {
  sessions: CreateSessionData[];
}

export const useSupabaseSessionsAdmin = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check for conflicts before creating sessions
  const checkSessionConflicts = async (sessions: CreateSessionData[]): Promise<SessionConflict[]> => {
    try {
      setError(null);
      
      // Create a list of date-time combinations to check
      const dateTimePairs = sessions.map(s => ({ date: s.date, time: s.time }));
      
      // Query existing sessions for these date-time combinations
      const conflicts: SessionConflict[] = [];
      
      for (const pair of dateTimePairs) {
        const { data: existingSessions, error } = await supabase
          .from('sessions')
          .select(`
            date,
            time,
            status,
            client:clients(name)
          `)
          .eq('date', pair.date)
          .eq('time', pair.time);

        if (error) {
          throw error;
        }

        if (existingSessions && existingSessions.length > 0) {
          existingSessions.forEach(session => {
            conflicts.push({
              date: session.date,
              time: session.time,
              status: session.status,
              client_name: session.client?.name
            });
          });
        }
      }
      
      return conflicts;
    } catch (err) {
      console.error('Error checking session conflicts:', err);
      setError('Failed to check for session conflicts');
      return [];
    }
  };

  // Create multiple sessions
  const createSessions = async (sessions: CreateSessionData[]): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);

      // Prepare session data for insertion
      const sessionsToInsert = sessions.map(session => ({
        date: session.date,
        time: session.time,
        status: session.status,
        duration_minutes: session.duration_minutes || 60,
        notes: session.notes,
        session_type: 'regular',
        // is_available will be set automatically by the trigger based on status
        client_id: null // Admin-created sessions start without a client
      }));

      const { error } = await supabase
        .from('sessions')
        .insert(sessionsToInsert);

      if (error) {
        console.error('Error creating sessions:', error);
        throw error;
      }

      return true;
    } catch (err) {
      console.error('Error creating sessions:', err);
      setError('Failed to create sessions');
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Get all sessions with client information for admin view
  const getAllSessionsWithClients = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('sessions')
        .select(`
          *,
          client:clients(*)
        `)
        .order('date', { ascending: true })
        .order('time', { ascending: true });

      if (error) {
        throw error;
      }

      return data || [];
    } catch (err) {
      console.error('Error loading sessions with clients:', err);
      setError('Failed to load sessions');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Update session status
  const updateSessionStatus = async (sessionId: string, status: string): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);

      const { error } = await supabase
        .from('sessions')
        .update({ status })
        .eq('id', sessionId);

      if (error) {
        throw error;
      }

      return true;
    } catch (err) {
      console.error('Error updating session status:', err);
      setError('Failed to update session status');
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Delete session
  const deleteSession = async (sessionId: string): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);

      const { error } = await supabase
        .from('sessions')
        .delete()
        .eq('id', sessionId);

      if (error) {
        throw error;
      }

      return true;
    } catch (err) {
      console.error('Error deleting session:', err);
      setError('Failed to delete session');
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    checkSessionConflicts,
    createSessions,
    getAllSessionsWithClients,
    updateSessionStatus,
    deleteSession
  };
};