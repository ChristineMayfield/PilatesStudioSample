import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please check your .env.local file.')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface Database {
  public: {
    Tables: {
      site_config: {
        Row: {
          id: number
          config_data: any
          updated_at: string
        }
        Insert: {
          id?: number
          config_data: any
          updated_at?: string
        }
        Update: {
          id?: number
          config_data?: any
          updated_at?: string
        }
      }
      sessions: {
        Row: {
          id: string
          date: string
          time: string
          duration_minutes: number
          is_available: boolean
          client_id: string | null
          session_type: string
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          date: string
          time: string
          duration_minutes?: number
          is_available?: boolean
          client_id?: string | null
          session_type?: string
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          date?: string
          time?: string
          duration_minutes?: number
          is_available?: boolean
          client_id?: string | null
          session_type?: string
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      clients: {
        Row: {
          id: string
          name: string
          email: string
          phone: string
          experience_level: string | null
          goals: string | null
          injuries: string | null
          package_type: string | null
          sessions_remaining: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          email: string
          phone: string
          experience_level?: string | null
          goals?: string | null
          injuries?: string | null
          package_type?: string | null
          sessions_remaining?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string
          phone?: string
          experience_level?: string | null
          goals?: string | null
          injuries?: string | null
          package_type?: string | null
          sessions_remaining?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}