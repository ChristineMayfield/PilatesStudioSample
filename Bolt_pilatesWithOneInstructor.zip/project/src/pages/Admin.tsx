import React, { useState } from 'react';
import { ArrowLeft, Save, Plus, Trash2, CheckCircle, Settings, Database, AlertCircle, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useSupabaseConfig } from '../hooks/useSupabaseConfig';
import { SiteConfig, PricingPackage, AddOnService } from '../config/siteConfig';
import SessionAdmin from '../components/SessionAdmin';
import ConnectionTest from '../components/ConnectionTest';

const Admin = () => {
  const { user, loading: authLoading } = useAuth();
  const { config, loading, error, updateConfig } = useSupabaseConfig();
  const [formData, setFormData] = useState<SiteConfig>(config);
  const [isSaved, setIsSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'pricing' | 'hours' | 'consultation' | 'sessions' | 'database'>('pricing');

  // Update form data when config loads
  React.useEffect(() => {
    setFormData(config);
  }, [config]);

  // Check if user is admin
  if (authLoading) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-sage-50 min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sage-600 mx-auto mb-4"></div>
            <p className="text-xl text-gray-600">Loading...</p>
          </div>
        </section>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-sage-50 min-h-screen flex items-center justify-center">
          <div className="text-center max-w-md">
            <Shield className="w-16 h-16 text-red-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Access Denied</h2>
            <p className="text-gray-600 mb-6">
              You must be signed in to access the admin dashboard.
            </p>
            <p className="text-sm text-gray-500">
              Please sign in using the person icon in the header.
            </p>
          </div>
        </section>
      </div>
    );
  }

  if (!user.admin) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-sage-50 min-h-screen flex items-center justify-center">
          <div className="text-center max-w-md">
            <Shield className="w-16 h-16 text-red-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Admin Access Required</h2>
            <p className="text-gray-600 mb-6">
              You don't have administrator privileges to access this page.
            </p>
            <p className="text-sm text-gray-500 mb-6">
              Contact the studio owner if you believe you should have admin access.
            </p>
            <Link
              to="/"
              className="bg-sage-600 hover:bg-sage-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-300"
            >
              Return Home
            </Link>
          </div>
        </section>
      </div>
    );
  }

  const handleSave = async () => {
    // Show confirmation dialog
    const confirmed = window.confirm('Are you sure you want to make these changes? This will update your website.');
    
    if (confirmed) {
      setIsSaving(true);
      const success = await updateConfig(formData);
      setIsSaving(false);
      
      if (success) {
        setIsSaved(true);
        
        // Hide the message after 5 seconds
        setTimeout(() => {
          setIsSaved(false);
        }, 5000);
      }
    }
  };

  const updateConsultationFee = (fee: string) => {
    setFormData(prev => ({
      ...prev,
      consultationFee: fee
    }));
  };

  const updatePricingPackage = (index: number, updatedPackage: PricingPackage) => {
    setFormData(prev => ({
      ...prev,
      pricingPackages: prev.pricingPackages.map((pkg, i) => 
        i === index ? updatedPackage : pkg
      )
    }));
  };

  const addPricingPackage = () => {
    const newPackage: PricingPackage = {
      name: "New Package",
      price: "$0",
      description: "Package description",
      features: ["Feature 1"],
      popular: false,
      buttonText: "Book Package"
    };
    setFormData(prev => ({
      ...prev,
      pricingPackages: [...prev.pricingPackages, newPackage]
    }));
  };

  const removePricingPackage = (index: number) => {
    if (formData.pricingPackages.length > 1) {
      setFormData(prev => ({
        ...prev,
        pricingPackages: prev.pricingPackages.filter((_, i) => i !== index)
      }));
    }
  };

  const updateAddOnService = (index: number, updatedService: AddOnService) => {
    setFormData(prev => ({
      ...prev,
      addOnServices: prev.addOnServices.map((service, i) => 
        i === index ? updatedService : service
      )
    }));
  };

  const addAddOnService = () => {
    const newService: AddOnService = {
      name: "New Service",
      price: "$0",
      description: "Service description"
    };
    setFormData(prev => ({
      ...prev,
      addOnServices: [...prev.addOnServices, newService]
    }));
  };

  const removeAddOnService = (index: number) => {
    if (formData.addOnServices.length > 1) {
      setFormData(prev => ({
        ...prev,
        addOnServices: prev.addOnServices.filter((_, i) => i !== index)
      }));
    }
  };

  const updateStudioHours = (day: keyof typeof formData.studioHours, hours: string) => {
    setFormData(prev => ({
      ...prev,
      studioHours: {
        ...prev.studioHours,
        [day]: hours
      }
    }));
  };

  const addFeature = (packageIndex: number) => {
    const updatedPackage = {
      ...formData.pricingPackages[packageIndex],
      features: [...formData.pricingPackages[packageIndex].features, "New feature"]
    };
    updatePricingPackage(packageIndex, updatedPackage);
  };

  const removeFeature = (packageIndex: number, featureIndex: number) => {
    const updatedPackage = {
      ...formData.pricingPackages[packageIndex],
      features: formData.pricingPackages[packageIndex].features.filter((_, i) => i !== featureIndex)
    };
    updatePricingPackage(packageIndex, updatedPackage);
  };

  const updateFeature = (packageIndex: number, featureIndex: number, newFeature: string) => {
    const updatedPackage = {
      ...formData.pricingPackages[packageIndex],
      features: formData.pricingPackages[packageIndex].features.map((feature, i) => 
        i === featureIndex ? newFeature : feature
      )
    };
    updatePricingPackage(packageIndex, updatedPackage);
  };

  if (loading) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-sage-50 min-h-screen flex items-center justify-center">
          <div className="text-center">
            <Database className="w-12 h-12 text-sage-600 mx-auto mb-4 animate-spin" />
            <p className="text-xl text-gray-600">Loading configuration from database...</p>
          </div>
        </section>
      </div>
    );
  }

  if (error) {
    return (
      <div className="pt-20">
        <section className="py-20 bg-sage-50 min-h-screen flex items-center justify-center">
          <div className="text-center max-w-md">
            <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Database Connection Error</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <p className="text-sm text-gray-500">
              Please check your Supabase configuration in the .env.local file.
            </p>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="pt-20">
      {/* Success Message - Fixed Position */}
      {isSaved && (
        <div className="fixed top-24 left-1/2 transform -translate-x-1/2 z-50 animate-pulse">
          <div className="flex items-center bg-green-100 border border-green-300 text-green-800 px-8 py-4 rounded-xl shadow-2xl">
            <CheckCircle className="w-6 h-6 mr-3 text-green-600" />
            <span className="font-bold text-lg">Changes saved to database! Your website has been updated.</span>
          </div>
        </div>
      )}

      <section className="py-20 bg-sage-50 min-h-screen">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center mb-8">
              <Link 
                to="/" 
                className="flex items-center text-sage-600 hover:text-sage-700 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Home
              </Link>
            </div>

            <div className="text-center mb-12">
              <div className="flex items-center justify-center mb-4">
                <Database className="w-8 h-8 text-sage-600 mr-3" />
                <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-800">
                  Admin Dashboard
                </h1>
              </div>
              <div className="w-24 h-1 bg-sage-600 mx-auto mb-6"></div>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Manage all variable content across your website. Changes are saved to your Supabase database 
                and reflected immediately across all pages.
              </p>
              <div className="mt-4 inline-flex items-center bg-sage-100 rounded-lg px-4 py-2">
                <Shield className="w-4 h-4 text-sage-700 mr-2" />
                <span className="text-sage-800 text-sm font-medium">
                  Logged in as: {user.name} (Administrator)
                </span>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="bg-white rounded-xl shadow-lg mb-8">
              <div className="flex border-b border-gray-200 overflow-x-auto">
                <button
                  onClick={() => setActiveTab('consultation')}
                  className={`px-6 py-4 font-semibold transition-colors duration-200 whitespace-nowrap ${
                    activeTab === 'consultation'
                      ? 'text-sage-600 border-b-2 border-sage-600'
                      : 'text-gray-600 hover:text-sage-600'
                  }`}
                >
                  Consultation Fee
                </button>
                <button
                  onClick={() => setActiveTab('pricing')}
                  className={`px-6 py-4 font-semibold transition-colors duration-200 whitespace-nowrap ${
                    activeTab === 'pricing'
                      ? 'text-sage-600 border-b-2 border-sage-600'
                      : 'text-gray-600 hover:text-sage-600'
                  }`}
                >
                  Pricing Packages
                </button>
                <button
                  onClick={() => setActiveTab('hours')}
                  className={`px-6 py-4 font-semibold transition-colors duration-200 whitespace-nowrap ${
                    activeTab === 'hours'
                      ? 'text-sage-600 border-b-2 border-sage-600'
                      : 'text-gray-600 hover:text-sage-600'
                  }`}
                >
                  Studio Hours
                </button>
                <button
                  onClick={() => setActiveTab('sessions')}
                  className={`px-6 py-4 font-semibold transition-colors duration-200 whitespace-nowrap ${
                    activeTab === 'sessions'
                      ? 'text-sage-600 border-b-2 border-sage-600'
                      : 'text-gray-600 hover:text-sage-600'
                  }`}
                >
                  Session Management
                </button>
                <button
                  onClick={() => setActiveTab('database')}
                  className={`px-6 py-4 font-semibold transition-colors duration-200 whitespace-nowrap ${
                    activeTab === 'database'
                      ? 'text-sage-600 border-b-2 border-sage-600'
                      : 'text-gray-600 hover:text-sage-600'
                  }`}
                >
                  Database Test
                </button>
              </div>

              <div className="p-8">
                {/* Database Test Tab */}
                {activeTab === 'database' && (
                  <div className="space-y-6">
                    <h3 className="font-serif text-2xl font-bold text-gray-800 mb-6">
                      Database Connection Test
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Test the connection to your Supabase database and verify that all data is accessible.
                    </p>
                    <ConnectionTest />
                  </div>
                )}

                {/* Session Management Tab */}
                {activeTab === 'sessions' && (
                  <SessionAdmin />
                )}

                {/* Consultation Fee Tab */}
                {activeTab === 'consultation' && (
                  <div className="space-y-6">
                    <h3 className="font-serif text-2xl font-bold text-gray-800 mb-6">
                      Initial Consultation Fee
                    </h3>
                    <div className="max-w-md">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Consultation Fee *
                      </label>
                      <input
                        type="text"
                        value={formData.consultationFee}
                        onChange={(e) => updateConsultationFee(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 transition-colors duration-200"
                        placeholder="$75"
                        required
                      />
                      <p className="text-sm text-gray-600 mt-2">
                        This fee appears on the booking section and throughout the site.
                      </p>
                    </div>
                  </div>
                )}

                {/* Pricing Packages Tab */}
                {activeTab === 'pricing' && (
                  <div className="space-y-8">
                    <div className="flex items-center justify-between">
                      <h3 className="font-serif text-2xl font-bold text-gray-800">
                        Pricing Packages
                      </h3>
                      <button
                        onClick={addPricingPackage}
                        className="flex items-center bg-sage-600 hover:bg-sage-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors duration-200"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Package
                      </button>
                    </div>

                    {formData.pricingPackages.map((pkg, index) => (
                      <div key={index} className="bg-sage-50 rounded-lg p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-lg text-gray-800">Package {index + 1}</h4>
                          {formData.pricingPackages.length > 1 && (
                            <button
                              onClick={() => removePricingPackage(index)}
                              className="text-red-600 hover:text-red-700 transition-colors duration-200"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          )}
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Package Name *
                            </label>
                            <input
                              type="text"
                              value={pkg.name}
                              onChange={(e) => updatePricingPackage(index, { ...pkg, name: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Price *
                            </label>
                            <input
                              type="text"
                              value={pkg.price}
                              onChange={(e) => updatePricingPackage(index, { ...pkg, price: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Original Price (Optional)
                            </label>
                            <input
                              type="text"
                              value={pkg.originalPrice || ''}
                              onChange={(e) => updatePricingPackage(index, { ...pkg, originalPrice: e.target.value || undefined })}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Button Text *
                            </label>
                            <input
                              type="text"
                              value={pkg.buttonText}
                              onChange={(e) => updatePricingPackage(index, { ...pkg, buttonText: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Description *
                          </label>
                          <textarea
                            value={pkg.description}
                            onChange={(e) => updatePricingPackage(index, { ...pkg, description: e.target.value })}
                            rows={2}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 resize-none"
                            required
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-3">
                            <label className="block text-sm font-medium text-gray-700">
                              Features *
                            </label>
                            <button
                              onClick={() => addFeature(index)}
                              className="text-sage-600 hover:text-sage-700 text-sm font-medium"
                            >
                              + Add Feature
                            </button>
                          </div>
                          <div className="space-y-2">
                            {pkg.features.map((feature, featureIndex) => (
                              <div key={featureIndex} className="flex items-center space-x-2">
                                <input
                                  type="text"
                                  value={feature}
                                  onChange={(e) => updateFeature(index, featureIndex, e.target.value)}
                                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                                  required
                                />
                                {pkg.features.length > 1 && (
                                  <button
                                    onClick={() => removeFeature(index, featureIndex)}
                                    className="text-red-600 hover:text-red-700"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id={`popular-${index}`}
                            checked={pkg.popular}
                            onChange={(e) => updatePricingPackage(index, { ...pkg, popular: e.target.checked })}
                            className="mr-2 rounded border-gray-300 text-sage-600 focus:ring-sage-500"
                          />
                          <label htmlFor={`popular-${index}`} className="text-sm font-medium text-gray-700">
                            Mark as Popular Package
                          </label>
                        </div>
                      </div>
                    ))}

                    {/* Additional Class Options */}
                    <div className="border-t border-gray-200 pt-8">
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="font-serif text-2xl font-bold text-gray-800">
                          Additional Class Options
                        </h3>
                        <button
                          onClick={addAddOnService}
                          className="flex items-center bg-sage-600 hover:bg-sage-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors duration-200"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Service
                        </button>
                      </div>

                      {formData.addOnServices.map((service, index) => (
                        <div key={index} className="bg-sage-50 rounded-lg p-6 mb-4">
                          <div className="flex items-center justify-between mb-4">
                            <h4 className="font-semibold text-lg text-gray-800">Service {index + 1}</h4>
                            {formData.addOnServices.length > 1 && (
                              <button
                                onClick={() => removeAddOnService(index)}
                                className="text-red-600 hover:text-red-700 transition-colors duration-200"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            )}
                          </div>

                          <div className="grid md:grid-cols-3 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                Service Name *
                              </label>
                              <input
                                type="text"
                                value={service.name}
                                onChange={(e) => updateAddOnService(index, { ...service, name: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                Price *
                              </label>
                              <input
                                type="text"
                                value={service.price}
                                onChange={(e) => updateAddOnService(index, { ...service, price: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                Description *
                              </label>
                              <input
                                type="text"
                                value={service.description}
                                onChange={(e) => updateAddOnService(index, { ...service, description: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                                required
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Studio Hours Tab */}
                {activeTab === 'hours' && (
                  <div className="space-y-6">
                    <h3 className="font-serif text-2xl font-bold text-gray-800 mb-6">
                      Studio Hours
                    </h3>
                    <div className="grid md:grid-cols-2 gap-6">
                      {Object.entries(formData.studioHours).map(([day, hours]) => (
                        <div key={day}>
                          <label className="block text-sm font-medium text-gray-700 mb-2 capitalize">
                            {day} *
                          </label>
                          <input
                            type="text"
                            value={hours}
                            onChange={(e) => updateStudioHours(day as keyof typeof formData.studioHours, e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 transition-colors duration-200"
                            placeholder="9:00 AM - 5:00 PM"
                            required
                          />
                        </div>
                      ))}
                    </div>
                    <p className="text-sm text-gray-600">
                      These hours will be displayed in the footer and contact page.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Action Buttons - Only show for non-session and non-database tabs */}
            {activeTab !== 'sessions' && activeTab !== 'database' && (
              <>
                <div className="flex justify-center">
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className={`flex items-center justify-center px-8 py-4 rounded-lg font-semibold transition-colors duration-300 shadow-lg hover:shadow-xl ${
                      isSaving
                        ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                        : 'bg-sage-600 hover:bg-sage-700 text-white'
                    }`}
                  >
                    <Save className="w-5 h-5 mr-2" />
                    {isSaving ? 'Saving to Database...' : 'Save All Changes'}
                  </button>
                </div>

                <div className="mt-6 text-center">
                  <p className="text-sm text-gray-600">
                    * Required fields must be completed before saving changes
                  </p>
                  <p className="text-xs text-gray-500 mt-2">
                    Changes are saved to your Supabase database and synced across all pages in real-time
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Admin;