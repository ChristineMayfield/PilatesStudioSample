import React, { useState } from 'react';
import { ArrowLeft, Calendar, Clock, User, X, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
  category: string;
}

const Blog = () => {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  const blogPosts: BlogPost[] = [
    {
      id: 1,
      title: "The Science Behind the Basi Method: Why Precision Matters",
      excerpt: "Discover how the Basi method's emphasis on precise movement patterns creates lasting transformation in your body and mind.",
      content: `
        <p>The Basi method of Pilates stands apart from other approaches through its unwavering commitment to precision and anatomical understanding. Developed by Rael Isacowitz, this method integrates classical Pilates principles with modern movement science to create a comprehensive system that truly transforms the body.</p>

        <h3>The Foundation of Precision</h3>
        <p>At the heart of the Basi method lies the principle that quality trumps quantity every time. Rather than rushing through movements, we focus on executing each exercise with perfect form and complete awareness. This precision-based approach ensures that every muscle fiber is engaged correctly, creating balanced strength throughout your entire body.</p>

        <h3>Anatomical Intelligence</h3>
        <p>What sets the Basi method apart is its deep integration of anatomical knowledge. Every movement is designed with a thorough understanding of how the body functions as an integrated system. This means we're not just working individual muscles – we're training movement patterns that translate directly to improved function in daily life.</p>

        <h3>The Mind-Body Connection</h3>
        <p>The Basi method emphasizes the crucial connection between mental focus and physical execution. This mindful approach to movement creates neural pathways that enhance coordination, balance, and proprioception. Students often report feeling more connected to their bodies and more aware of their posture and movement patterns throughout the day.</p>

        <h3>Progressive Development</h3>
        <p>The method follows a logical progression that builds upon itself. Each exercise prepares your body for the next level of challenge, ensuring safe and sustainable development. This systematic approach prevents injury while maximizing results, making it suitable for everyone from beginners to advanced practitioners.</p>

        <p>When you experience the Basi method, you're not just doing Pilates – you're participating in a scientifically-backed system that has been refined over decades to deliver optimal results. The precision required may seem challenging at first, but it's this very attention to detail that creates the profound transformations our clients experience.</p>
      `,
      author: "Sarah Johnson",
      date: "January 15, 2024",
      readTime: "5 min read",
      image: "https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      category: "Method & Technique"
    },
    {
      id: 2,
      title: "5 Signs Your Core Needs Attention (And How Pilates Can Help)",
      excerpt: "Learn to recognize the subtle signs that your core strength needs work and discover how targeted Pilates exercises can restore balance.",
      content: `
        <p>Your core is far more than just your abdominal muscles – it's the powerhouse that supports every movement you make. Yet many people don't realize their core needs attention until they experience pain or dysfunction. Here are five key signs that indicate your core could benefit from focused Pilates training.</p>

        <h3>1. Lower Back Pain That Won't Go Away</h3>
        <p>Chronic lower back pain is often a cry for help from an overworked spine that isn't getting adequate support from the core muscles. When your deep abdominal muscles, pelvic floor, and diaphragm aren't working together effectively, your back muscles compensate, leading to tension and pain.</p>
        
        <p>Pilates addresses this by teaching you to engage your deep core muscles properly, creating a natural "corset" of support around your spine. Through exercises like the Hundred, Dead Bug, and modified Plank variations, we retrain these muscles to work as they should.</p>

        <h3>2. Poor Posture That You Can't Seem to Fix</h3>
        <p>If you find yourself constantly slouching despite your best efforts to sit up straight, your core may lack the endurance to maintain good posture throughout the day. A weak core forces other muscles to work overtime, leading to the rounded shoulders and forward head posture so common in our digital age.</p>

        <p>Pilates exercises like the Roll Up, Spine Stretch Forward, and Swan help strengthen the muscles that support proper spinal alignment while improving flexibility in tight areas.</p>

        <h3>3. Difficulty with Balance and Coordination</h3>
        <p>Your core is your body's center of gravity and stability. When it's not functioning optimally, you may notice increased clumsiness, difficulty standing on one foot, or feeling unsteady during activities that require balance.</p>

        <p>Single-leg exercises, standing balance challenges, and unstable surface training in Pilates help retrain your proprioceptive system and improve overall stability.</p>

        <h3>4. Breathing Feels Shallow or Restricted</h3>
        <p>The diaphragm is a crucial part of your core system. If you find yourself breathing primarily into your chest rather than your belly, or if you feel like you can't take a deep breath, your core coordination may be compromised.</p>

        <p>Pilates emphasizes proper breathing patterns that coordinate with movement, helping to restore optimal diaphragm function and improve overall respiratory efficiency.</p>

        <h3>5. Exercise Feels Harder Than It Should</h3>
        <p>If basic exercises leave you feeling exhausted or if you struggle with movements that should be within your fitness level, your core may not be providing the stable foundation needed for efficient movement.</p>

        <p>A strong, coordinated core makes all movement more efficient. When it's working properly, you'll find that other exercises become easier and more enjoyable.</p>

        <h3>The Pilates Solution</h3>
        <p>The beauty of Pilates is that it addresses all these issues simultaneously. Rather than isolating individual muscles, Pilates trains your core as an integrated system, teaching coordination, strength, and endurance in functional movement patterns.</p>

        <p>If you recognize yourself in any of these signs, don't wait for the problem to worsen. A comprehensive assessment can identify your specific needs, and a personalized Pilates program can help restore your core function, leading to better posture, reduced pain, and improved overall quality of life.</p>
      `,
      author: "Sarah Johnson",
      date: "January 8, 2024",
      readTime: "7 min read",
      image: "https://images.pexels.com/photos/4056535/pexels-photo-4056535.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      category: "Health & Wellness"
    },
    {
      id: 3,
      title: "Creating Your Home Practice: Essential Equipment and Exercises",
      excerpt: "Build an effective home Pilates practice with minimal equipment and maximum results using these expert-recommended exercises.",
      content: `
        <p>While nothing replaces the personalized attention and professional equipment of studio sessions, developing a home practice can significantly accelerate your Pilates journey. Here's how to create an effective home routine that complements your studio work.</p>

        <h3>Essential Equipment for Home Practice</h3>
        <p>You don't need a full studio setup to practice effectively at home. Here are the key pieces that will give you the most versatility:</p>

        <h4>1. A Quality Mat</h4>
        <p>Invest in a mat that's at least 6mm thick for adequate cushioning. Look for one with good grip and sufficient length (at least 68 inches) to accommodate full-body movements.</p>

        <h4>2. Resistance Bands</h4>
        <p>A set of resistance bands with varying tensions can replicate many reformer exercises. Look for bands with comfortable handles and door attachments for maximum versatility.</p>

        <h4>3. Small Props</h4>
        <p>A Pilates ball (9-inch), magic circle, and foam roller can add variety and challenge to your routine. These props help target specific muscle groups and add instability training.</p>

        <h3>Building Your Routine</h3>
        <p>A well-rounded home practice should include elements of strength, flexibility, and coordination. Here's a framework for a 30-minute session:</p>

        <h4>Warm-Up (5 minutes)</h4>
        <ul>
          <li>Breathing exercises to center and prepare</li>
          <li>Gentle spinal mobility (Cat-Cow, Spinal Waves)</li>
          <li>Joint mobility for shoulders and hips</li>
        </ul>

        <h4>Core Foundation (10 minutes)</h4>
        <ul>
          <li>The Hundred (modified as needed)</li>
          <li>Single Leg Circles</li>
          <li>Rolling Like a Ball</li>
          <li>Single Leg Stretch series</li>
        </ul>

        <h4>Strength and Stability (10 minutes)</h4>
        <ul>
          <li>Plank variations</li>
          <li>Side-lying leg series</li>
          <li>Bridge variations</li>
          <li>Standing balance challenges</li>
        </ul>

        <h4>Flexibility and Integration (5 minutes)</h4>
        <ul>
          <li>Spine Stretch Forward</li>
          <li>Saw or Mermaid stretch</li>
          <li>Hip flexor stretches</li>
          <li>Final relaxation</li>
        </ul>

        <h3>Making It Sustainable</h3>
        <p>The key to a successful home practice is consistency over intensity. Start with 15-20 minutes, 3 times per week, and gradually build up. Quality of movement is always more important than quantity.</p>

        <h3>When to Seek Guidance</h3>
        <p>While home practice is valuable, regular check-ins with a qualified instructor are essential. They can correct form issues, progress your exercises appropriately, and ensure you're practicing safely.</p>

        <p>Remember, your home practice should complement, not replace, your studio sessions. Use it as a way to reinforce what you're learning and maintain your progress between appointments.</p>
      `,
      author: "Sarah Johnson",
      date: "December 28, 2023",
      readTime: "6 min read",
      image: "https://images.pexels.com/photos/4498597/pexels-photo-4498597.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      category: "Home Practice"
    },
    {
      id: 4,
      title: "Pilates for Athletes: Enhancing Performance and Preventing Injury",
      excerpt: "Discover how professional athletes use Pilates to gain a competitive edge and maintain peak performance throughout their careers.",
      content: `
        <p>From NBA stars to Olympic swimmers, elite athletes across all sports have discovered the transformative power of Pilates. Far from being just a gentle form of exercise, Pilates offers athletes a sophisticated training system that enhances performance while reducing injury risk.</p>

        <h3>The Athletic Advantage</h3>
        <p>Athletes face unique physical demands that can create imbalances, compensations, and eventual breakdown. Traditional training often focuses on sport-specific movements and maximum output, sometimes at the expense of balanced development. Pilates fills this gap by addressing the whole body as an integrated system.</p>

        <h3>Core Power for Athletic Performance</h3>
        <p>Every athletic movement begins with the core. Whether you're throwing a baseball, jumping for a rebound, or sprinting down a track, power generation starts from your center and transfers outward through your limbs. Pilates trains this power transfer more effectively than any other method.</p>

        <p>Unlike traditional core training that often focuses on isolated muscle contractions, Pilates teaches dynamic core stability – the ability to maintain a strong, stable center while your limbs move at high speeds and varying loads.</p>

        <h3>Injury Prevention Through Balance</h3>
        <p>Most sports create predictable imbalances. Runners develop tight hip flexors and weak glutes. Tennis players have stronger dominant sides. Cyclists develop rounded postures. These imbalances, left unchecked, eventually lead to injury.</p>

        <p>Pilates systematically addresses these imbalances by:</p>
        <ul>
          <li>Strengthening weak, underused muscles</li>
          <li>Stretching tight, overused areas</li>
          <li>Improving movement quality and efficiency</li>
          <li>Enhancing proprioception and body awareness</li>
        </ul>

        <h3>Mental Training Benefits</h3>
        <p>The mental focus required in Pilates directly translates to improved athletic performance. The concentration needed to execute precise movements while maintaining proper breathing and alignment trains the same mental skills needed for peak athletic performance.</p>

        <p>Athletes often report improved body awareness, better ability to make micro-adjustments during competition, and enhanced mental resilience after incorporating Pilates into their training.</p>

        <h3>Recovery and Regeneration</h3>
        <p>Pilates serves as active recovery, promoting blood flow and lymphatic drainage while maintaining movement quality. The controlled, flowing movements help flush metabolic waste from muscles while maintaining flexibility and joint mobility.</p>

        <h3>Sport-Specific Applications</h3>
        <p>While Pilates principles remain consistent, the application can be tailored to specific sports:</p>

        <h4>Runners</h4>
        <p>Focus on hip stability, glute activation, and thoracic spine mobility to improve running efficiency and reduce overuse injuries.</p>

        <h4>Golfers</h4>
        <p>Emphasize rotational power, spinal mobility, and weight transfer patterns that directly translate to improved swing mechanics.</p>

        <h4>Team Sport Athletes</h4>
        <p>Develop multi-directional stability, reactive core strength, and movement variability to handle the unpredictable demands of game situations.</p>

        <h3>Integration with Training</h3>
        <p>The key to success is proper integration with existing training programs. Pilates works best when it complements, rather than competes with, sport-specific training. Many athletes find 2-3 Pilates sessions per week optimal for maintaining balance without interfering with their primary training.</p>

        <p>Whether you're a weekend warrior or a competitive athlete, Pilates can help you move better, perform stronger, and stay healthier throughout your athletic journey.</p>
      `,
      author: "Sarah Johnson",
      date: "December 20, 2023",
      readTime: "8 min read",
      image: "https://images.pexels.com/photos/4498592/pexels-photo-4498592.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      category: "Athletic Performance"
    },
    {
      id: 5,
      title: "The Mind-Body Connection: How Pilates Reduces Stress and Anxiety",
      excerpt: "Explore the profound mental health benefits of Pilates and learn how mindful movement can be your pathway to inner peace.",
      content: `
        <p>In our fast-paced, high-stress world, the search for effective stress management has never been more critical. While many people turn to Pilates for physical benefits, the mental health advantages are equally profound and often life-changing.</p>

        <h3>The Science of Stress Relief</h3>
        <p>Pilates activates the parasympathetic nervous system – your body's "rest and digest" response – through its emphasis on controlled breathing and mindful movement. This physiological shift counteracts the chronic stress response that plagues so many of us in modern life.</p>

        <p>Research shows that regular Pilates practice can:</p>
        <ul>
          <li>Lower cortisol levels (the primary stress hormone)</li>
          <li>Reduce symptoms of anxiety and depression</li>
          <li>Improve sleep quality and duration</li>
          <li>Enhance overall mood and emotional regulation</li>
        </ul>

        <h3>Breathing as Medicine</h3>
        <p>The Pilates breathing pattern – deep, coordinated breaths that engage the diaphragm – is one of the most powerful stress-reduction tools available. This type of breathing:</p>

        <ul>
          <li>Activates the vagus nerve, promoting relaxation</li>
          <li>Increases oxygen delivery to the brain</li>
          <li>Helps regulate heart rate variability</li>
          <li>Provides an anchor for present-moment awareness</li>
        </ul>

        <p>Many clients report that learning proper Pilates breathing becomes a go-to tool for managing stress throughout their day, whether in traffic, before important meetings, or during challenging situations.</p>

        <h3>Moving Meditation</h3>
        <p>Pilates can be thought of as moving meditation. The requirement for complete focus on precise movement patterns naturally quiets mental chatter and brings you into the present moment. This mindful state provides a respite from anxious thoughts about the future or regrets about the past.</p>

        <p>The concentration required to coordinate breath, movement, and alignment creates what psychologists call "flow state" – a mental condition where you become fully immersed in the activity, leading to reduced stress and increased feelings of well-being.</p>

        <h3>Building Resilience</h3>
        <p>Regular Pilates practice builds both physical and mental resilience. As you learn to maintain composure and control during challenging exercises, you develop the same skills needed to handle life's stressors with greater equanimity.</p>

        <p>The progressive nature of Pilates – gradually building strength, flexibility, and coordination – mirrors the process of building emotional resilience. Each small success builds confidence and self-efficacy.</p>

        <h3>Body Awareness and Emotional Intelligence</h3>
        <p>Pilates enhances interoception – your ability to sense internal bodily signals. This increased body awareness often translates to better emotional awareness, helping you recognize stress signals earlier and respond more effectively.</p>

        <p>Many clients discover that physical tension patterns mirror emotional holding patterns. As they learn to release physical tension through Pilates, they often experience corresponding emotional release and greater psychological flexibility.</p>

        <h3>The Social Connection</h3>
        <p>While private sessions offer personalized attention, the supportive community aspect of Pilates can also contribute to stress reduction. Feeling connected to others who share similar wellness goals provides social support and reduces feelings of isolation.</p>

        <h3>Creating Your Stress-Relief Practice</h3>
        <p>To maximize the stress-relief benefits of Pilates:</p>

        <ul>
          <li>Focus on breath awareness throughout your practice</li>
          <li>Approach each session with curiosity rather than judgment</li>
          <li>Allow yourself to be fully present during exercises</li>
          <li>Notice how you feel before and after each session</li>
          <li>Use Pilates breathing techniques throughout your day</li>
        </ul>

        <p>Remember, the goal isn't to eliminate stress entirely – that's neither possible nor desirable. Instead, Pilates helps you develop a healthier relationship with stress, building the tools and resilience needed to navigate life's challenges with greater ease and grace.</p>

        <p>In a world that often feels chaotic and overwhelming, your Pilates practice can become a sanctuary – a place where you reconnect with your body, calm your mind, and restore your sense of inner peace.</p>
      `,
      author: "Sarah Johnson",
      date: "December 12, 2023",
      readTime: "7 min read",
      image: "https://images.pexels.com/photos/4498591/pexels-photo-4498591.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      category: "Mental Health"
    },
    {
      id: 6,
      title: "Pilates Through the Decades: Adapting Your Practice as You Age",
      excerpt: "Learn how to modify and evolve your Pilates practice to meet your changing needs throughout different life stages.",
      content: `
        <p>One of the most beautiful aspects of Pilates is its adaptability. Unlike many forms of exercise that become more difficult or even impossible as we age, Pilates can be modified and evolved to meet your changing needs throughout every decade of life.</p>

        <h3>Your 20s and 30s: Building the Foundation</h3>
        <p>During these decades, your body is typically at its physical peak, making this an ideal time to establish proper movement patterns and build a strong foundation. Focus areas include:</p>

        <ul>
          <li>Learning precise technique and proper form</li>
          <li>Building core strength and stability</li>
          <li>Developing flexibility and mobility</li>
          <li>Establishing consistent practice habits</li>
        </ul>

        <p>This is also the time to address any imbalances created by sports, work postures, or lifestyle habits before they become problematic. The movement patterns you learn now will serve you for decades to come.</p>

        <h3>Your 40s: Maintaining and Preventing</h3>
        <p>The 40s often bring the first signs of age-related changes – perhaps some stiffness in the morning, occasional aches, or decreased energy. Pilates becomes increasingly valuable for:</p>

        <ul>
          <li>Maintaining bone density through weight-bearing exercises</li>
          <li>Preserving muscle mass and strength</li>
          <li>Managing stress and hormonal changes</li>
          <li>Preventing the onset of chronic conditions</li>
        </ul>

        <p>This decade is crucial for establishing Pilates as a non-negotiable part of your wellness routine. The consistency you build now will pay dividends later.</p>

        <h3>Your 50s: Adapting and Thriving</h3>
        <p>The 50s often bring significant life changes – menopause, career transitions, or caring for aging parents. Your Pilates practice can be a stabilizing force during these transitions:</p>

        <ul>
          <li>Addressing hormonal changes that affect bone density and muscle mass</li>
          <li>Managing stress and supporting mental health</li>
          <li>Maintaining balance and coordination</li>
          <li>Adapting exercises for any developing limitations</li>
        </ul>

        <p>This is when the wisdom of proper form learned in earlier decades becomes apparent. Quality of movement becomes even more important than quantity.</p>

        <h3>Your 60s and Beyond: Optimizing Function</h3>
        <p>In your 60s and beyond, Pilates becomes less about performance and more about maintaining independence and quality of life:</p>

        <ul>
          <li>Preserving functional movement patterns</li>
          <li>Maintaining balance to prevent falls</li>
          <li>Supporting cognitive function through complex movement patterns</li>
          <li>Managing chronic conditions like arthritis or osteoporosis</li>
        </ul>

        <h3>Key Modifications by Decade</h3>

        <h4>Range of Motion</h4>
        <p>As we age, we may need to work within smaller ranges of motion. The key is maintaining what you have and gradually working to improve where possible, always respecting your body's current limitations.</p>

        <h4>Intensity and Duration</h4>
        <p>Younger practitioners might focus on challenging, dynamic sequences, while older adults may benefit from slower, more controlled movements with longer holds and more rest between exercises.</p>

        <h4>Equipment Adaptations</h4>
        <p>Props and equipment modifications become increasingly valuable with age. Chairs for support, blocks for positioning, and resistance bands for gentler strengthening can make exercises accessible regardless of physical limitations.</p>

        <h3>The Lifelong Benefits</h3>
        <p>Research consistently shows that people who maintain regular Pilates practice throughout their lives experience:</p>

        <ul>
          <li>Better balance and reduced fall risk</li>
          <li>Maintained bone density</li>
          <li>Improved cognitive function</li>
          <li>Greater independence in daily activities</li>
          <li>Enhanced quality of life and life satisfaction</li>
        </ul>

        <h3>Starting at Any Age</h3>
        <p>It's never too late to begin. Whether you're 25 or 75, Pilates can be adapted to meet you where you are. The key is working with a qualified instructor who understands how to modify exercises appropriately for your age, fitness level, and any physical limitations.</p>

        <p>Remember, the goal isn't to turn back the clock, but to optimize your function and vitality at every stage of life. Pilates provides the tools to age gracefully, maintaining strength, flexibility, and confidence throughout your journey.</p>

        <p>Your body will change over the decades – that's natural and inevitable. But with Pilates as your companion, you can ensure that those changes don't limit your ability to live fully and move with joy at every age.</p>
      `,
      author: "Sarah Johnson",
      date: "December 5, 2023",
      readTime: "9 min read",
      image: "https://images.pexels.com/photos/4498590/pexels-photo-4498590.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      category: "Aging & Wellness"
    }
  ];

  const openModal = (post: BlogPost) => {
    setSelectedPost(post);
    document.body.style.overflow = 'hidden';
  };

  const closeModal = () => {
    setSelectedPost(null);
    document.body.style.overflow = 'unset';
  };

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-sage-100 to-beige-100 overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: 'url("https://images.pexels.com/photos/4056535/pexels-photo-4056535.jpeg?auto=compress&cs=tinysrgb&w=1920&h=800&fit=crop")'
          }}
        ></div>
        
        <div className="relative z-10 container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center mb-8">
              <Link 
                to="/" 
                className="flex items-center text-sage-600 hover:text-sage-700 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Home
              </Link>
            </div>

            <h1 className="font-serif text-4xl md:text-6xl font-bold text-gray-800 mb-6">
              Wellness Insights & 
              <span className="text-sage-600 block">Pilates Wisdom</span>
            </h1>
            <div className="w-24 h-1 bg-sage-600 mx-auto mb-8"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Discover expert insights, practical tips, and inspiring stories to deepen your understanding 
              of Pilates and enhance your wellness journey. From technique refinements to lifestyle wisdom, 
              explore articles crafted to support your transformation.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-3 md:grid-cols-2 gap-8">
              {blogPosts.map((post) => (
                <article
                  key={post.id}
                  className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer group"
                  onClick={() => openModal(post)}
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-sage-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                        {post.category}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex items-center text-sm text-gray-500 mb-3 space-x-4">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {post.date}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {post.readTime}
                      </div>
                    </div>
                    
                    <h2 className="font-serif text-xl font-bold text-gray-800 mb-3 group-hover:text-sage-600 transition-colors duration-200">
                      {post.title}
                    </h2>
                    
                    <p className="text-gray-600 mb-4 leading-relaxed">
                      {post.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <User className="w-4 h-4 text-sage-600 mr-2" />
                        <span className="text-sm text-gray-600">{post.author}</span>
                      </div>
                      <div className="flex items-center text-sage-600 group-hover:text-sage-700 transition-colors duration-200">
                        <span className="text-sm font-medium mr-1">Read More</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Modal */}
      {selectedPost && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white z-10 flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                <span className="bg-sage-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                  {selectedPost.category}
                </span>
                <div className="flex items-center text-sm text-gray-500 space-x-4">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    {selectedPost.date}
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    {selectedPost.readTime}
                  </div>
                  <div className="flex items-center">
                    <User className="w-4 h-4 mr-1" />
                    {selectedPost.author}
                  </div>
                </div>
              </div>
              <button
                onClick={closeModal}
                className="bg-gray-100 hover:bg-gray-200 rounded-full p-2 transition-all duration-200"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
            </div>
            
            <div className="p-8">
              <img
                src={selectedPost.image}
                alt={selectedPost.title}
                className="w-full h-64 object-cover rounded-lg mb-8"
              />
              
              <h1 className="font-serif text-3xl md:text-4xl font-bold text-gray-800 mb-6">
                {selectedPost.title}
              </h1>
              
              <div 
                className="prose prose-lg max-w-none text-gray-700 leading-relaxed"
                dangerouslySetInnerHTML={{ __html: selectedPost.content }}
                style={{
                  lineHeight: '1.8',
                }}
              />
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .prose h3 {
          font-family: Georgia, serif;
          font-size: 1.5rem;
          font-weight: 700;
          color: #4a5e4a;
          margin-top: 2rem;
          margin-bottom: 1rem;
        }
        .prose h4 {
          font-family: Georgia, serif;
          font-size: 1.25rem;
          font-weight: 600;
          color: #5d755d;
          margin-top: 1.5rem;
          margin-bottom: 0.75rem;
        }
        .prose p {
          margin-bottom: 1.25rem;
        }
        .prose ul {
          margin: 1.25rem 0;
          padding-left: 1.5rem;
        }
        .prose li {
          margin-bottom: 0.5rem;
        }
      `}</style>
    </div>
  );
};

export default Blog;