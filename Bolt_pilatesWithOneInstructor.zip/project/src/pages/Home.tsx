import React from 'react';
import Hero from '../components/Hero';
import About from '../components/About';
import Studio from '../components/Studio';
import Testimonials from '../components/Testimonials';
import Booking from '../components/Booking';

const Home = () => {
  return (
    <>
      <Hero />
      <About />
      <Studio />
      <Testimonials />
      <Booking />
    </>
  );
};

export default Home;