import React from 'react';
import { Check, Star, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useConfig } from '../hooks/useConfig';

const Pricing = () => {
  const { config } = useConfig();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="pt-20">
      <section className="py-20 bg-sage-50">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center mb-8">
              <Link 
                to="/" 
                className="flex items-center text-sage-600 hover:text-sage-700 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Home
              </Link>
            </div>

            <div className="text-center mb-16">
              <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 mb-6">
                Investment in Your Wellness
              </h1>
              <div className="w-24 h-1 bg-sage-600 mx-auto mb-8"></div>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Choose the package that best fits your goals and schedule. All sessions include personalized 
                attention, expert instruction, and a commitment to your transformation.
              </p>
            </div>

            {/* Pricing Grid with proper spacing for popular badge */}
            <div className="grid lg:grid-cols-3 gap-8 mb-16" style={{ paddingTop: '2rem' }}>
              {config.pricingPackages.map((pkg, index) => (
                <div
                  key={index}
                  className={`relative bg-white rounded-2xl shadow-lg transition-transform duration-300 hover:scale-105 ${
                    pkg.popular ? 'ring-2 ring-sage-500 transform scale-105' : ''
                  }`}
                  style={{ overflow: 'visible' }}
                >
                  {pkg.popular && (
                    <div 
                      className="absolute left-1/2 transform -translate-x-1/2"
                      style={{ top: '-1rem', zIndex: 10 }}
                    >
                      <div className="bg-sage-600 text-white px-6 py-2 rounded-full text-sm font-semibold flex items-center space-x-1 shadow-lg">
                        <Star className="w-4 h-4 fill-current" />
                        <span>Most Popular</span>
                      </div>
                    </div>
                  )}
                  
                  <div className={`p-8 ${pkg.popular ? 'pt-12' : ''}`}>
                    <h3 className="font-serif text-2xl font-bold text-gray-800 mb-2">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-600 mb-6">{pkg.description}</p>
                    
                    <div className="mb-6">
                      <div className="flex items-baseline space-x-2">
                        <span className="text-4xl font-bold text-sage-600">{pkg.price}</span>
                        {pkg.originalPrice && (
                          <span className="text-xl text-gray-400 line-through">{pkg.originalPrice}</span>
                        )}
                      </div>
                      {pkg.originalPrice && (
                        <p className="text-sm text-green-600 font-medium mt-1">
                          Save ${parseInt(pkg.originalPrice.substring(1)) - parseInt(pkg.price.substring(1))}
                        </p>
                      )}
                    </div>
                    
                    <ul className="space-y-3 mb-8">
                      {pkg.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start space-x-3">
                          <Check className="w-5 h-5 text-sage-600 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Link
                      to="/"
                      onClick={scrollToTop}
                      className={`block w-full py-3 px-6 rounded-full font-semibold text-center transition-colors duration-300 ${
                        pkg.popular
                          ? 'bg-sage-600 hover:bg-sage-700 text-white'
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                      }`}
                    >
                      {pkg.buttonText}
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg mb-12">
              <h3 className="font-serif text-3xl font-bold text-gray-800 mb-8 text-center">
                Additional Class Options
              </h3>
              <div className="grid md:grid-cols-3 gap-6">
                {config.addOnServices.map((addon, index) => (
                  <div key={index} className="text-center p-6 border border-sage-200 rounded-lg hover:border-sage-400 transition-colors duration-300">
                    <h4 className="font-semibold text-xl text-gray-800 mb-2">{addon.name}</h4>
                    <p className="text-2xl font-bold text-sage-600 mb-3">{addon.price}</p>
                    <p className="text-gray-600 text-sm">{addon.description}</p>
                  </div>
                ))}
              </div>
              
              {/* Group Classes Message */}
              <div className="mt-8 text-center">
                <div className="bg-sage-50 border border-sage-200 rounded-lg p-6">
                  <p className="text-sage-800 font-medium">
                    Send us a message from our{' '}
                    <Link 
                      to="/contact" 
                      className="text-sage-600 hover:text-sage-700 underline font-semibold transition-colors duration-200"
                    >
                      Contact page
                    </Link>
                    {' '}to book group classes
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-sage-100 rounded-xl p-8 text-center">
              <h3 className="font-serif text-2xl font-bold text-gray-800 mb-4">
                Flexible Payment Options
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 text-gray-700">
                <div>
                  <h4 className="font-semibold mb-2">Payment Methods</h4>
                  <p className="text-sm">Cash, Credit, Debit, Venmo, Zelle</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Package Validity</h4>
                  <p className="text-sm">Sessions never expire</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Cancellation</h4>
                  <p className="text-sm">24-hour notice required</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Rescheduling</h4>
                  <p className="text-sm">Free with advance notice</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Pricing;