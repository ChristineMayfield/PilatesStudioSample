/*
  # Normalize Database Schema - Remove Client Data Duplication

  1. Schema Changes
    - Convert both tables to use UUID primary keys
    - Add client_id foreign key to sessions table
    - Remove duplicate client fields from sessions table
    - Add proper foreign key constraints

  2. Data Migration
    - Preserve existing data by matching sessions to clients
    - Handle orphaned sessions gracefully
    - Maintain referential integrity

  3. Performance
    - Add proper indexes for foreign key relationships
    - Optimize queries with client relationships
*/

-- Step 1: Add client_id column to sessions table first
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'client_id'
  ) THEN
    ALTER TABLE sessions ADD COLUMN client_id UUID;
  END IF;
END $$;

-- Step 2: Convert clients table to use UUID primary key
DO $$
BEGIN
  -- Add new UUID column to clients if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'clients' AND column_name = 'new_id'
  ) THEN
    ALTER TABLE clients ADD COLUMN new_id UUID DEFAULT gen_random_uuid();
    
    -- Ensure all rows have UUIDs
    UPDATE clients SET new_id = gen_random_uuid() WHERE new_id IS NULL;
  END IF;
END $$;

-- Step 3: Migrate existing session data to reference clients using old integer IDs
DO $$
BEGIN
  -- Try to match sessions to clients by email first (using old integer id)
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'client_email'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'clients' AND column_name = 'id' AND data_type = 'integer'
  ) THEN
    UPDATE sessions 
    SET client_id = clients.new_id
    FROM clients 
    WHERE sessions.client_email = clients.email
      AND sessions.client_email IS NOT NULL
      AND sessions.client_id IS NULL;
      
    -- Then try to match by name for remaining sessions
    UPDATE sessions 
    SET client_id = clients.new_id
    FROM clients 
    WHERE sessions.client_name = clients.name
      AND sessions.client_id IS NULL
      AND sessions.client_name IS NOT NULL;
  END IF;
END $$;

-- Step 4: Convert clients table structure (drop old constraints and columns)
DO $$
BEGIN
  -- Check if we still have the old integer id column
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'clients' AND column_name = 'id' AND data_type = 'integer'
  ) THEN
    -- Drop old constraints
    ALTER TABLE clients DROP CONSTRAINT IF EXISTS clients_pkey;
    ALTER TABLE clients DROP CONSTRAINT IF EXISTS clients_email_key;
    ALTER TABLE clients DROP CONSTRAINT IF EXISTS clients_email_unique;
    
    -- Drop old id column and rename new_id to id
    ALTER TABLE clients DROP COLUMN id;
    ALTER TABLE clients RENAME COLUMN new_id TO id;
    
    -- Add new constraints
    ALTER TABLE clients ADD PRIMARY KEY (id);
    ALTER TABLE clients ADD CONSTRAINT clients_email_unique UNIQUE (email);
  END IF;
END $$;

-- Step 5: Convert sessions table to use UUID primary key
DO $$
BEGIN
  -- Check if sessions table still uses integer id
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'id' AND data_type = 'integer'
  ) THEN
    -- Add new UUID column
    ALTER TABLE sessions ADD COLUMN new_id UUID DEFAULT gen_random_uuid();
    
    -- Ensure all rows have UUIDs
    UPDATE sessions SET new_id = gen_random_uuid() WHERE new_id IS NULL;
    
    -- Drop old primary key and rename columns
    ALTER TABLE sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
    ALTER TABLE sessions DROP COLUMN id;
    ALTER TABLE sessions RENAME COLUMN new_id TO id;
    
    -- Add new primary key
    ALTER TABLE sessions ADD PRIMARY KEY (id);
  END IF;
END $$;

-- Step 6: Remove duplicate client data columns from sessions
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'client_name'
  ) THEN
    ALTER TABLE sessions DROP COLUMN client_name;
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'client_email'
  ) THEN
    ALTER TABLE sessions DROP COLUMN client_email;
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'client_phone'
  ) THEN
    ALTER TABLE sessions DROP COLUMN client_phone;
  END IF;
END $$;

-- Step 7: Add foreign key constraint (now that both tables use UUID)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_sessions_client_id'
  ) THEN
    ALTER TABLE sessions ADD CONSTRAINT fk_sessions_client_id 
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Step 8: Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_sessions_client_id ON sessions(client_id);
CREATE INDEX IF NOT EXISTS idx_sessions_date_time_new ON sessions(date, time);
CREATE INDEX IF NOT EXISTS idx_sessions_available_new ON sessions(is_available);
CREATE INDEX IF NOT EXISTS idx_clients_email_new ON clients(email);
CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(name);

-- Step 9: Update RLS policies for normalized schema
DROP POLICY IF EXISTS "Anyone can read session availability" ON sessions;
DROP POLICY IF EXISTS "Anyone can book sessions" ON sessions;
DROP POLICY IF EXISTS "Anyone can create sessions" ON sessions;
DROP POLICY IF EXISTS "Public can read sessions" ON sessions;
DROP POLICY IF EXISTS "Public can update sessions" ON sessions;
DROP POLICY IF EXISTS "Public can create sessions" ON sessions;
DROP POLICY IF EXISTS "Public can delete sessions" ON sessions;

DROP POLICY IF EXISTS "Clients can read own data" ON clients;
DROP POLICY IF EXISTS "Anyone can create client records" ON clients;
DROP POLICY IF EXISTS "Anyone can update client records" ON clients;
DROP POLICY IF EXISTS "Public can read clients" ON clients;
DROP POLICY IF EXISTS "Public can create clients" ON clients;
DROP POLICY IF EXISTS "Public can update clients" ON clients;

-- Sessions policies
CREATE POLICY "Public can read sessions"
  ON sessions
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can update sessions"
  ON sessions
  FOR UPDATE
  TO public
  USING (true);

CREATE POLICY "Public can create sessions"
  ON sessions
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public can delete sessions"
  ON sessions
  FOR DELETE
  TO public
  USING (true);

-- Clients policies
CREATE POLICY "Public can read clients"
  ON clients
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can create clients"
  ON clients
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public can update clients"
  ON clients
  FOR UPDATE
  TO public
  USING (true);

-- Step 10: Create some sample data with proper relationships if needed
DO $$
DECLARE
  client_uuid UUID;
BEGIN
  -- Only insert sample data if no clients exist
  IF NOT EXISTS (SELECT 1 FROM clients LIMIT 1) THEN
    INSERT INTO clients (name, email, phone, experience_level, goals, sessions_remaining)
    VALUES ('Sample Client', 'sample@example.com', '(555) 123-4567', 'beginner', 'Improve posture and flexibility', 0)
    RETURNING id INTO client_uuid;
    
    -- Insert a sample session linked to this client
    INSERT INTO sessions (date, time, is_available, client_id, session_type, notes)
    VALUES (CURRENT_DATE + INTERVAL '1 day', '10:00 AM', false, client_uuid, 'consultation', 'Initial consultation session');
  END IF;
END $$;