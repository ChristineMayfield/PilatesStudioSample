/*
  # Add Session Status Field and Admin Functionality

  1. Schema Changes
    - Add status field to sessions table with proper enum values
    - Update existing sessions to have 'available' or 'confirmed' status
    - Add indexes for better performance

  2. Security
    - Update RLS policies to handle new status field
    - Maintain existing permissions structure
*/

-- Add status column to sessions table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'status'
  ) THEN
    -- Create enum type for session status
    CREATE TYPE session_status AS ENUM ('blocked', 'available', 'pending_confirmation', 'confirmed', 'completed');
    
    -- Add status column with default value
    ALTER TABLE sessions ADD COLUMN status session_status DEFAULT 'available';
    
    -- Update existing sessions based on current is_available and client_id
    UPDATE sessions 
    SET status = CASE 
      WHEN is_available = true AND client_id IS NULL THEN 'available'::session_status
      WHEN is_available = false AND client_id IS NOT NULL THEN 'confirmed'::session_status
      ELSE 'available'::session_status
    END;
    
    -- Make status NOT NULL after setting defaults
    ALTER TABLE sessions ALTER COLUMN status SET NOT NULL;
  END IF;
END $$;

-- Add index for status field
CREATE INDEX IF NOT EXISTS idx_sessions_status ON sessions(status);

-- Add composite index for common queries
CREATE INDEX IF NOT EXISTS idx_sessions_date_status ON sessions(date, status);

-- Update the is_available field to be computed from status
-- Keep it for backward compatibility but update it automatically
CREATE OR REPLACE FUNCTION update_is_available_from_status()
RETURNS TRIGGER AS $$
BEGIN
  NEW.is_available = (NEW.status = 'available');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update is_available when status changes
DROP TRIGGER IF EXISTS trigger_update_is_available ON sessions;
CREATE TRIGGER trigger_update_is_available
  BEFORE INSERT OR UPDATE ON sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_is_available_from_status();