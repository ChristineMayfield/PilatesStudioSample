/*
  # Add Password Field to Clients Table

  1. Schema Changes
    - Add password field to clients table
    - Set default password 'password' for all existing clients
    - Add indexes for authentication queries

  2. Security
    - Password field for simple authentication
    - Update existing clients with default password
*/

-- Add password column to clients table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'clients' AND column_name = 'password'
  ) THEN
    ALTER TABLE clients ADD COLUMN password TEXT;
    
    -- Set default password for all existing clients
    UPDATE clients SET password = 'password' WHERE password IS NULL;
    
    -- Make password NOT NULL after setting defaults
    ALTER TABLE clients ALTER COLUMN password SET NOT NULL;
    ALTER TABLE clients ALTER COLUMN password SET DEFAULT 'password';
  END IF;
END $$;

-- Add index for email lookups (authentication)
CREATE INDEX IF NOT EXISTS idx_clients_email_auth ON clients(email);