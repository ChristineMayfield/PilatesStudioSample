/*
  # Add Admin Column to Clients Table

  1. Schema Changes
    - Add admin boolean column to clients table
    - Set default value to false for all existing clients
    - Add index for admin queries

  2. Security
    - Update existing clients to have admin = false
    - Maintain existing RLS policies
*/

-- Add admin column to clients table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'clients' AND column_name = 'admin'
  ) THEN
    ALTER TABLE clients ADD COLUMN admin BOOLEAN DEFAULT false;
    
    -- Set admin = false for all existing clients
    UPDATE clients SET admin = false WHERE admin IS NULL;
    
    -- Make admin NOT NULL after setting defaults
    ALTER TABLE clients ALTER COLUMN admin SET NOT NULL;
  END IF;
END $$;

-- Add index for admin queries
CREATE INDEX IF NOT EXISTS idx_clients_admin ON clients(admin);